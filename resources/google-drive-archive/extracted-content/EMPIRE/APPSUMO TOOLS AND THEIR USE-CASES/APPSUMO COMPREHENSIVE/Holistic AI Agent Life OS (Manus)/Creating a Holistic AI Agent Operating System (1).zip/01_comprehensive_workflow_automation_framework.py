#!/usr/bin/env python3
"""
AI Agent Life Operating System - Comprehensive Workflow Automation Framework

This framework provides the foundation for creating, managing, and executing complex
business and personal life workflows that integrate all 209 AppSumo tools through
the 15 specialized AI agents. The system supports both predefined workflows and
dynamic workflow generation based on business objectives and personal goals.

Author: Manus AI
Date: July 8, 2025
Version: 1.0
"""

import asyncio
import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Union, Callable, Set, Tuple
import uuid
import threading
from concurrent.futures import ThreadPoolExecutor
import queue
import networkx as nx
import yaml
from pathlib import Path

import redis
import psycopg2
from psycopg2.extras import RealDictCursor
import schedule
from celery import Celery
from celery.result import AsyncResult
import pydantic
from pydantic import BaseModel, Field


class WorkflowStatus(Enum):
    """Workflow execution status"""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class WorkflowPriority(Enum):
    """Workflow priority levels"""
    CRITICAL = 1
    HIGH = 2
    MEDIUM = 3
    LOW = 4
    BACKGROUND = 5


class WorkflowType(Enum):
    """Types of workflows"""
    BUSINESS_PROCESS = "business_process"
    PERSONAL_MANAGEMENT = "personal_management"
    REVENUE_GENERATION = "revenue_generation"
    CONTENT_CREATION = "content_creation"
    CUSTOMER_JOURNEY = "customer_journey"
    OPERATIONAL = "operational"
    ANALYTICAL = "analytical"
    MAINTENANCE = "maintenance"


class TriggerType(Enum):
    """Workflow trigger types"""
    MANUAL = "manual"
    SCHEDULED = "scheduled"
    EVENT_DRIVEN = "event_driven"
    CONDITION_BASED = "condition_based"
    API_TRIGGERED = "api_triggered"
    WEBHOOK = "webhook"


@dataclass
class WorkflowStep:
    """Individual step within a workflow"""
    step_id: str
    step_name: str
    agent_id: str
    task_type: str
    parameters: Dict[str, Any]
    dependencies: List[str] = field(default_factory=list)
    conditions: Dict[str, Any] = field(default_factory=dict)
    timeout_seconds: int = 3600
    retry_policy: Dict[str, Any] = field(default_factory=dict)
    success_criteria: Dict[str, Any] = field(default_factory=dict)
    failure_handling: Dict[str, Any] = field(default_factory=dict)
    parallel_execution: bool = False
    optional: bool = False


@dataclass
class WorkflowTrigger:
    """Workflow trigger configuration"""
    trigger_id: str
    trigger_type: TriggerType
    trigger_config: Dict[str, Any]
    conditions: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True


@dataclass
class WorkflowDefinition:
    """Complete workflow definition"""
    workflow_id: str
    workflow_name: str
    workflow_type: WorkflowType
    description: str
    version: str
    steps: List[WorkflowStep]
    triggers: List[WorkflowTrigger]
    priority: WorkflowPriority = WorkflowPriority.MEDIUM
    timeout_seconds: int = 7200
    retry_policy: Dict[str, Any] = field(default_factory=dict)
    success_criteria: Dict[str, Any] = field(default_factory=dict)
    failure_handling: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)


@dataclass
class WorkflowExecution:
    """Workflow execution instance"""
    execution_id: str
    workflow_id: str
    status: WorkflowStatus
    trigger_data: Dict[str, Any]
    step_executions: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    error_message: Optional[str] = None
    result_data: Dict[str, Any] = field(default_factory=dict)
    metrics: Dict[str, Any] = field(default_factory=dict)


class WorkflowEngine:
    """Core workflow execution engine"""
    
    def __init__(self, 
                 redis_client: redis.Redis,
                 db_connection,
                 agent_orchestrator,
                 event_system):
        
        self.redis_client = redis_client
        self.db_connection = db_connection
        self.agent_orchestrator = agent_orchestrator
        self.event_system = event_system
        
        self.logger = logging.getLogger("WorkflowEngine")
        self.workflow_definitions: Dict[str, WorkflowDefinition] = {}
        self.active_executions: Dict[str, WorkflowExecution] = {}
        self.execution_graph = nx.DiGraph()
        
        # Workflow execution control
        self.running = False
        self.executor = ThreadPoolExecutor(max_workers=10)
        
        # Performance tracking
        self.execution_metrics = {
            "total_executions": 0,
            "successful_executions": 0,
            "failed_executions": 0,
            "average_execution_time": 0.0
        }
        
        # Initialize workflow scheduler
        self.scheduler = WorkflowScheduler(self)
        
        # Initialize workflow builder
        self.builder = WorkflowBuilder(self)
    
    async def start(self):
        """Start the workflow engine"""
        self.running = True
        self.logger.info("Workflow Engine started")
        
        # Load workflow definitions from database
        await self._load_workflow_definitions()
        
        # Start execution loop
        asyncio.create_task(self._execution_loop())
        
        # Start scheduler
        await self.scheduler.start()
        
        # Register event handlers
        await self._register_event_handlers()
    
    async def stop(self):
        """Stop the workflow engine gracefully"""
        self.running = False
        
        # Wait for active executions to complete
        while self.active_executions:
            await asyncio.sleep(1)
        
        await self.scheduler.stop()
        self.executor.shutdown(wait=True)
        self.logger.info("Workflow Engine stopped")
    
    async def _load_workflow_definitions(self):
        """Load workflow definitions from database"""
        try:
            with self.db_connection.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute("SELECT * FROM workflow_definitions WHERE enabled = true")
                results = cursor.fetchall()
                
                for row in results:
                    workflow_def = self._deserialize_workflow_definition(row)
                    self.workflow_definitions[workflow_def.workflow_id] = workflow_def
                    
                self.logger.info(f"Loaded {len(self.workflow_definitions)} workflow definitions")
        
        except Exception as e:
            self.logger.error(f"Failed to load workflow definitions: {str(e)}")
    
    def _deserialize_workflow_definition(self, row: Dict) -> WorkflowDefinition:
        """Deserialize workflow definition from database row"""
        steps_data = json.loads(row["steps"])
        triggers_data = json.loads(row["triggers"])
        
        steps = [WorkflowStep(**step_data) for step_data in steps_data]
        triggers = [WorkflowTrigger(**trigger_data) for trigger_data in triggers_data]
        
        return WorkflowDefinition(
            workflow_id=row["workflow_id"],
            workflow_name=row["workflow_name"],
            workflow_type=WorkflowType(row["workflow_type"]),
            description=row["description"],
            version=row["version"],
            steps=steps,
            triggers=triggers,
            priority=WorkflowPriority(row["priority"]),
            timeout_seconds=row["timeout_seconds"],
            retry_policy=json.loads(row["retry_policy"]),
            success_criteria=json.loads(row["success_criteria"]),
            failure_handling=json.loads(row["failure_handling"]),
            metadata=json.loads(row["metadata"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"]
        )
    
    async def _execution_loop(self):
        """Main workflow execution loop"""
        while self.running:
            try:
                # Check for triggered workflows
                await self._check_workflow_triggers()
                
                # Process active executions
                await self._process_active_executions()
                
                # Clean up completed executions
                await self._cleanup_completed_executions()
                
                # Update metrics
                await self._update_execution_metrics()
                
                await asyncio.sleep(1)  # Brief pause
                
            except Exception as e:
                self.logger.error(f"Error in execution loop: {str(e)}")
                await asyncio.sleep(5)
    
    async def _check_workflow_triggers(self):
        """Check for workflow triggers and start executions"""
        for workflow_def in self.workflow_definitions.values():
            for trigger in workflow_def.triggers:
                if trigger.enabled and await self._evaluate_trigger(trigger):
                    await self.start_workflow_execution(
                        workflow_def.workflow_id,
                        trigger_data={"trigger_id": trigger.trigger_id}
                    )
    
    async def _evaluate_trigger(self, trigger: WorkflowTrigger) -> bool:
        """Evaluate if a trigger condition is met"""
        if trigger.trigger_type == TriggerType.SCHEDULED:
            return await self._evaluate_scheduled_trigger(trigger)
        elif trigger.trigger_type == TriggerType.EVENT_DRIVEN:
            return await self._evaluate_event_trigger(trigger)
        elif trigger.trigger_type == TriggerType.CONDITION_BASED:
            return await self._evaluate_condition_trigger(trigger)
        else:
            return False
    
    async def _evaluate_scheduled_trigger(self, trigger: WorkflowTrigger) -> bool:
        """Evaluate scheduled trigger"""
        # This would integrate with the scheduler
        return False  # Placeholder
    
    async def _evaluate_event_trigger(self, trigger: WorkflowTrigger) -> bool:
        """Evaluate event-driven trigger"""
        # Check for events in Redis
        event_key = f"workflow_events:{trigger.trigger_config.get('event_type')}"
        event_data = self.redis_client.lpop(event_key)
        
        if event_data:
            event = json.loads(event_data)
            return self._match_event_conditions(event, trigger.conditions)
        
        return False
    
    async def _evaluate_condition_trigger(self, trigger: WorkflowTrigger) -> bool:
        """Evaluate condition-based trigger"""
        conditions = trigger.conditions
        
        # Evaluate each condition
        for condition_key, condition_value in conditions.items():
            if not await self._evaluate_condition(condition_key, condition_value):
                return False
        
        return True
    
    def _match_event_conditions(self, event: Dict, conditions: Dict) -> bool:
        """Check if event matches trigger conditions"""
        for key, expected_value in conditions.items():
            if event.get(key) != expected_value:
                return False
        return True
    
    async def _evaluate_condition(self, condition_key: str, condition_value: Any) -> bool:
        """Evaluate a specific condition"""
        # This would implement condition evaluation logic
        # For now, return False as placeholder
        return False
    
    async def start_workflow_execution(self, 
                                     workflow_id: str, 
                                     trigger_data: Dict[str, Any] = None) -> str:
        """Start a new workflow execution"""
        if workflow_id not in self.workflow_definitions:
            raise ValueError(f"Workflow definition not found: {workflow_id}")
        
        execution_id = str(uuid.uuid4())
        workflow_def = self.workflow_definitions[workflow_id]
        
        execution = WorkflowExecution(
            execution_id=execution_id,
            workflow_id=workflow_id,
            status=WorkflowStatus.PENDING,
            trigger_data=trigger_data or {},
            start_time=datetime.now()
        )
        
        self.active_executions[execution_id] = execution
        
        # Start execution
        asyncio.create_task(self._execute_workflow(execution, workflow_def))
        
        self.logger.info(f"Started workflow execution: {execution_id}")
        return execution_id
    
    async def _execute_workflow(self, 
                               execution: WorkflowExecution, 
                               workflow_def: WorkflowDefinition):
        """Execute a workflow"""
        try:
            execution.status = WorkflowStatus.RUNNING
            
            # Build execution graph
            execution_graph = self._build_execution_graph(workflow_def.steps)
            
            # Execute steps in dependency order
            await self._execute_workflow_steps(execution, workflow_def, execution_graph)
            
            # Check success criteria
            if await self._check_success_criteria(execution, workflow_def.success_criteria):
                execution.status = WorkflowStatus.COMPLETED
                execution.end_time = datetime.now()
                
                # Publish completion event
                await self.event_system.publish_event(
                    "workflow.completed",
                    {
                        "execution_id": execution.execution_id,
                        "workflow_id": execution.workflow_id,
                        "duration": (execution.end_time - execution.start_time).total_seconds()
                    }
                )
            else:
                execution.status = WorkflowStatus.FAILED
                execution.error_message = "Success criteria not met"
        
        except Exception as e:
            execution.status = WorkflowStatus.FAILED
            execution.error_message = str(e)
            execution.end_time = datetime.now()
            
            self.logger.error(f"Workflow execution failed: {execution.execution_id}, Error: {str(e)}")
            
            # Handle failure
            await self._handle_workflow_failure(execution, workflow_def)
        
        finally:
            # Save execution results
            await self._save_execution_results(execution)
            
            # Update metrics
            self._update_workflow_metrics(execution)
    
    def _build_execution_graph(self, steps: List[WorkflowStep]) -> nx.DiGraph:
        """Build execution graph from workflow steps"""
        graph = nx.DiGraph()
        
        # Add all steps as nodes
        for step in steps:
            graph.add_node(step.step_id, step=step)
        
        # Add dependency edges
        for step in steps:
            for dependency in step.dependencies:
                graph.add_edge(dependency, step.step_id)
        
        # Validate graph (check for cycles)
        if not nx.is_directed_acyclic_graph(graph):
            raise ValueError("Workflow contains circular dependencies")
        
        return graph
    
    async def _execute_workflow_steps(self, 
                                    execution: WorkflowExecution,
                                    workflow_def: WorkflowDefinition,
                                    execution_graph: nx.DiGraph):
        """Execute workflow steps in dependency order"""
        # Get topological order for execution
        execution_order = list(nx.topological_sort(execution_graph))
        
        # Track completed steps
        completed_steps = set()
        
        for step_id in execution_order:
            step = execution_graph.nodes[step_id]['step']
            
            # Check if dependencies are completed
            dependencies_met = all(dep in completed_steps for dep in step.dependencies)
            
            if not dependencies_met:
                continue
            
            # Execute step
            step_result = await self._execute_workflow_step(execution, step)
            
            # Store step execution result
            execution.step_executions[step_id] = step_result
            
            # Check if step succeeded
            if step_result.get("status") == "success":
                completed_steps.add(step_id)
            elif not step.optional:
                # Required step failed
                raise Exception(f"Required step failed: {step_id}")
    
    async def _execute_workflow_step(self, 
                                   execution: WorkflowExecution,
                                   step: WorkflowStep) -> Dict[str, Any]:
        """Execute a single workflow step"""
        step_start_time = datetime.now()
        
        try:
            # Prepare step parameters
            step_parameters = self._prepare_step_parameters(execution, step)
            
            # Create task for agent
            task_data = {
                "task_type": step.task_type,
                "data": step_parameters,
                "priority": 2,  # High priority for workflow tasks
                "deadline": (datetime.now() + timedelta(seconds=step.timeout_seconds)).isoformat()
            }
            
            # Submit task to agent orchestrator
            task_id = await self.agent_orchestrator.distribute_task(task_data)
            
            # Wait for task completion
            task_result = await self._wait_for_task_completion(task_id, step.timeout_seconds)
            
            step_end_time = datetime.now()
            execution_time = (step_end_time - step_start_time).total_seconds()
            
            # Evaluate success criteria
            success = await self._evaluate_step_success(task_result, step.success_criteria)
            
            return {
                "status": "success" if success else "failed",
                "task_id": task_id,
                "result": task_result,
                "execution_time": execution_time,
                "start_time": step_start_time.isoformat(),
                "end_time": step_end_time.isoformat()
            }
        
        except Exception as e:
            step_end_time = datetime.now()
            execution_time = (step_end_time - step_start_time).total_seconds()
            
            # Handle step failure
            if step.retry_policy.get("enabled", False):
                return await self._retry_workflow_step(execution, step, str(e))
            
            return {
                "status": "failed",
                "error": str(e),
                "execution_time": execution_time,
                "start_time": step_start_time.isoformat(),
                "end_time": step_end_time.isoformat()
            }
    
    def _prepare_step_parameters(self, 
                               execution: WorkflowExecution,
                               step: WorkflowStep) -> Dict[str, Any]:
        """Prepare parameters for step execution"""
        parameters = step.parameters.copy()
        
        # Substitute variables from execution context
        parameters = self._substitute_variables(parameters, execution)
        
        # Add execution context
        parameters["execution_context"] = {
            "execution_id": execution.execution_id,
            "workflow_id": execution.workflow_id,
            "trigger_data": execution.trigger_data,
            "previous_step_results": execution.step_executions
        }
        
        return parameters
    
    def _substitute_variables(self, 
                            parameters: Dict[str, Any],
                            execution: WorkflowExecution) -> Dict[str, Any]:
        """Substitute variables in parameters"""
        # This would implement variable substitution logic
        # For now, return parameters as-is
        return parameters
    
    async def _wait_for_task_completion(self, task_id: str, timeout_seconds: int) -> Dict[str, Any]:
        """Wait for task completion with timeout"""
        start_time = time.time()
        
        while time.time() - start_time < timeout_seconds:
            # Check task status (this would integrate with agent orchestrator)
            task_status = await self._get_task_status(task_id)
            
            if task_status.get("status") == "completed":
                return task_status.get("result", {})
            elif task_status.get("status") == "failed":
                raise Exception(f"Task failed: {task_status.get('error')}")
            
            await asyncio.sleep(1)
        
        raise Exception(f"Task timeout: {task_id}")
    
    async def _get_task_status(self, task_id: str) -> Dict[str, Any]:
        """Get task status from agent orchestrator"""
        # This would integrate with the actual agent orchestrator
        # For now, return simulated status
        return {
            "status": "completed",
            "result": {"success": True, "data": {}}
        }
    
    async def _evaluate_step_success(self, 
                                   task_result: Dict[str, Any],
                                   success_criteria: Dict[str, Any]) -> bool:
        """Evaluate if step execution was successful"""
        if not success_criteria:
            return task_result.get("success", True)
        
        # Evaluate each success criterion
        for criterion_key, criterion_value in success_criteria.items():
            if not self._evaluate_criterion(task_result, criterion_key, criterion_value):
                return False
        
        return True
    
    def _evaluate_criterion(self, 
                          result: Dict[str, Any],
                          criterion_key: str,
                          criterion_value: Any) -> bool:
        """Evaluate a specific success criterion"""
        # This would implement criterion evaluation logic
        # For now, return True as placeholder
        return True
    
    async def _retry_workflow_step(self, 
                                 execution: WorkflowExecution,
                                 step: WorkflowStep,
                                 error_message: str) -> Dict[str, Any]:
        """Retry a failed workflow step"""
        retry_policy = step.retry_policy
        max_retries = retry_policy.get("max_retries", 3)
        backoff_factor = retry_policy.get("backoff_factor", 2)
        
        for attempt in range(max_retries):
            # Wait with exponential backoff
            wait_time = backoff_factor ** attempt
            await asyncio.sleep(wait_time)
            
            try:
                # Retry step execution
                return await self._execute_workflow_step(execution, step)
            except Exception as e:
                if attempt == max_retries - 1:
                    # Final attempt failed
                    return {
                        "status": "failed",
                        "error": f"Step failed after {max_retries} retries: {str(e)}",
                        "original_error": error_message
                    }
        
        return {"status": "failed", "error": "Retry logic error"}
    
    async def _check_success_criteria(self, 
                                    execution: WorkflowExecution,
                                    success_criteria: Dict[str, Any]) -> bool:
        """Check if workflow execution meets success criteria"""
        if not success_criteria:
            # Default: all required steps must succeed
            return all(
                result.get("status") == "success" 
                for result in execution.step_executions.values()
            )
        
        # Evaluate custom success criteria
        for criterion_key, criterion_value in success_criteria.items():
            if not self._evaluate_workflow_criterion(execution, criterion_key, criterion_value):
                return False
        
        return True
    
    def _evaluate_workflow_criterion(self, 
                                   execution: WorkflowExecution,
                                   criterion_key: str,
                                   criterion_value: Any) -> bool:
        """Evaluate a workflow-level success criterion"""
        # This would implement workflow criterion evaluation
        # For now, return True as placeholder
        return True
    
    async def _handle_workflow_failure(self, 
                                     execution: WorkflowExecution,
                                     workflow_def: WorkflowDefinition):
        """Handle workflow failure"""
        failure_handling = workflow_def.failure_handling
        
        if failure_handling.get("retry_enabled", False):
            # Retry entire workflow
            await self._retry_workflow(execution, workflow_def)
        
        if failure_handling.get("notification_enabled", False):
            # Send failure notification
            await self._send_failure_notification(execution, workflow_def)
        
        if failure_handling.get("rollback_enabled", False):
            # Rollback changes
            await self._rollback_workflow_changes(execution, workflow_def)
    
    async def _retry_workflow(self, 
                            execution: WorkflowExecution,
                            workflow_def: WorkflowDefinition):
        """Retry failed workflow"""
        retry_policy = workflow_def.retry_policy
        
        if retry_policy.get("enabled", False):
            max_retries = retry_policy.get("max_retries", 1)
            current_retries = execution.metrics.get("retry_count", 0)
            
            if current_retries < max_retries:
                # Create new execution for retry
                new_execution_id = await self.start_workflow_execution(
                    workflow_def.workflow_id,
                    execution.trigger_data
                )
                
                # Update retry count
                new_execution = self.active_executions[new_execution_id]
                new_execution.metrics["retry_count"] = current_retries + 1
                new_execution.metrics["original_execution_id"] = execution.execution_id
    
    async def _send_failure_notification(self, 
                                       execution: WorkflowExecution,
                                       workflow_def: WorkflowDefinition):
        """Send workflow failure notification"""
        notification_data = {
            "execution_id": execution.execution_id,
            "workflow_id": execution.workflow_id,
            "workflow_name": workflow_def.workflow_name,
            "error_message": execution.error_message,
            "failed_steps": [
                step_id for step_id, result in execution.step_executions.items()
                if result.get("status") == "failed"
            ]
        }
        
        await self.event_system.publish_event("workflow.failed", notification_data)
    
    async def _rollback_workflow_changes(self, 
                                       execution: WorkflowExecution,
                                       workflow_def: WorkflowDefinition):
        """Rollback changes made by failed workflow"""
        # This would implement rollback logic
        # For now, just log the rollback attempt
        self.logger.info(f"Rolling back workflow changes: {execution.execution_id}")
    
    async def _save_execution_results(self, execution: WorkflowExecution):
        """Save workflow execution results to database"""
        try:
            with self.db_connection.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO workflow_executions (
                        execution_id, workflow_id, status, trigger_data,
                        step_executions, start_time, end_time, error_message,
                        result_data, metrics
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (execution_id) DO UPDATE SET
                        status = EXCLUDED.status,
                        step_executions = EXCLUDED.step_executions,
                        end_time = EXCLUDED.end_time,
                        error_message = EXCLUDED.error_message,
                        result_data = EXCLUDED.result_data,
                        metrics = EXCLUDED.metrics
                """, (
                    execution.execution_id,
                    execution.workflow_id,
                    execution.status.value,
                    json.dumps(execution.trigger_data),
                    json.dumps(execution.step_executions),
                    execution.start_time,
                    execution.end_time,
                    execution.error_message,
                    json.dumps(execution.result_data),
                    json.dumps(execution.metrics)
                ))
            self.db_connection.commit()
        
        except Exception as e:
            self.logger.error(f"Failed to save execution results: {str(e)}")
    
    def _update_workflow_metrics(self, execution: WorkflowExecution):
        """Update workflow execution metrics"""
        self.execution_metrics["total_executions"] += 1
        
        if execution.status == WorkflowStatus.COMPLETED:
            self.execution_metrics["successful_executions"] += 1
        elif execution.status == WorkflowStatus.FAILED:
            self.execution_metrics["failed_executions"] += 1
        
        # Update average execution time
        if execution.start_time and execution.end_time:
            execution_time = (execution.end_time - execution.start_time).total_seconds()
            total_executions = self.execution_metrics["total_executions"]
            current_avg = self.execution_metrics["average_execution_time"]
            
            self.execution_metrics["average_execution_time"] = (
                (current_avg * (total_executions - 1) + execution_time) / total_executions
            )
    
    async def _process_active_executions(self):
        """Process and monitor active executions"""
        current_time = datetime.now()
        
        for execution_id, execution in list(self.active_executions.items()):
            # Check for timeouts
            if execution.start_time:
                execution_duration = (current_time - execution.start_time).total_seconds()
                workflow_def = self.workflow_definitions.get(execution.workflow_id)
                
                if workflow_def and execution_duration > workflow_def.timeout_seconds:
                    execution.status = WorkflowStatus.FAILED
                    execution.error_message = "Workflow timeout"
                    execution.end_time = current_time
                    
                    await self._save_execution_results(execution)
                    self._update_workflow_metrics(execution)
    
    async def _cleanup_completed_executions(self):
        """Clean up completed executions from memory"""
        completed_executions = [
            execution_id for execution_id, execution in self.active_executions.items()
            if execution.status in [WorkflowStatus.COMPLETED, WorkflowStatus.FAILED, WorkflowStatus.CANCELLED]
        ]
        
        for execution_id in completed_executions:
            del self.active_executions[execution_id]
    
    async def _update_execution_metrics(self):
        """Update and persist execution metrics"""
        # Save metrics to Redis for monitoring
        metrics_key = "workflow_engine:metrics"
        self.redis_client.hset(
            metrics_key,
            mapping={
                "total_executions": self.execution_metrics["total_executions"],
                "successful_executions": self.execution_metrics["successful_executions"],
                "failed_executions": self.execution_metrics["failed_executions"],
                "average_execution_time": self.execution_metrics["average_execution_time"],
                "active_executions": len(self.active_executions),
                "last_updated": datetime.now().isoformat()
            }
        )
    
    async def _register_event_handlers(self):
        """Register event handlers for workflow triggers"""
        await self.event_system.subscribe_to_events(
            ["lead.generated", "content.created", "task.completed"],
            self._handle_workflow_event
        )
    
    async def _handle_workflow_event(self, event: Dict[str, Any]):
        """Handle events that may trigger workflows"""
        event_type = event.get("event_type")
        event_data = event.get("data", {})
        
        # Store event for trigger evaluation
        event_key = f"workflow_events:{event_type}"
        self.redis_client.lpush(event_key, json.dumps(event))
        self.redis_client.expire(event_key, 3600)  # 1 hour expiration
    
    # Public API methods
    
    async def create_workflow_definition(self, workflow_def: WorkflowDefinition) -> str:
        """Create a new workflow definition"""
        # Validate workflow definition
        self._validate_workflow_definition(workflow_def)
        
        # Save to database
        await self._save_workflow_definition(workflow_def)
        
        # Add to memory
        self.workflow_definitions[workflow_def.workflow_id] = workflow_def
        
        self.logger.info(f"Created workflow definition: {workflow_def.workflow_id}")
        return workflow_def.workflow_id
    
    def _validate_workflow_definition(self, workflow_def: WorkflowDefinition):
        """Validate workflow definition"""
        # Check for required fields
        if not workflow_def.workflow_id:
            raise ValueError("Workflow ID is required")
        
        if not workflow_def.steps:
            raise ValueError("Workflow must have at least one step")
        
        # Validate step dependencies
        step_ids = {step.step_id for step in workflow_def.steps}
        for step in workflow_def.steps:
            for dependency in step.dependencies:
                if dependency not in step_ids:
                    raise ValueError(f"Invalid dependency: {dependency}")
        
        # Check for circular dependencies
        execution_graph = self._build_execution_graph(workflow_def.steps)
        if not nx.is_directed_acyclic_graph(execution_graph):
            raise ValueError("Workflow contains circular dependencies")
    
    async def _save_workflow_definition(self, workflow_def: WorkflowDefinition):
        """Save workflow definition to database"""
        try:
            with self.db_connection.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO workflow_definitions (
                        workflow_id, workflow_name, workflow_type, description,
                        version, steps, triggers, priority, timeout_seconds,
                        retry_policy, success_criteria, failure_handling,
                        metadata, enabled, created_at, updated_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (workflow_id) DO UPDATE SET
                        workflow_name = EXCLUDED.workflow_name,
                        description = EXCLUDED.description,
                        version = EXCLUDED.version,
                        steps = EXCLUDED.steps,
                        triggers = EXCLUDED.triggers,
                        priority = EXCLUDED.priority,
                        timeout_seconds = EXCLUDED.timeout_seconds,
                        retry_policy = EXCLUDED.retry_policy,
                        success_criteria = EXCLUDED.success_criteria,
                        failure_handling = EXCLUDED.failure_handling,
                        metadata = EXCLUDED.metadata,
                        updated_at = EXCLUDED.updated_at
                """, (
                    workflow_def.workflow_id,
                    workflow_def.workflow_name,
                    workflow_def.workflow_type.value,
                    workflow_def.description,
                    workflow_def.version,
                    json.dumps([step.__dict__ for step in workflow_def.steps]),
                    json.dumps([trigger.__dict__ for trigger in workflow_def.triggers]),
                    workflow_def.priority.value,
                    workflow_def.timeout_seconds,
                    json.dumps(workflow_def.retry_policy),
                    json.dumps(workflow_def.success_criteria),
                    json.dumps(workflow_def.failure_handling),
                    json.dumps(workflow_def.metadata),
                    True,  # enabled
                    workflow_def.created_at,
                    workflow_def.updated_at
                ))
            self.db_connection.commit()
        
        except Exception as e:
            self.logger.error(f"Failed to save workflow definition: {str(e)}")
            raise
    
    async def get_workflow_status(self, execution_id: str) -> Dict[str, Any]:
        """Get workflow execution status"""
        if execution_id in self.active_executions:
            execution = self.active_executions[execution_id]
            return {
                "execution_id": execution.execution_id,
                "workflow_id": execution.workflow_id,
                "status": execution.status.value,
                "start_time": execution.start_time.isoformat() if execution.start_time else None,
                "end_time": execution.end_time.isoformat() if execution.end_time else None,
                "step_executions": execution.step_executions,
                "error_message": execution.error_message
            }
        else:
            # Check database for completed executions
            return await self._get_execution_from_database(execution_id)
    
    async def _get_execution_from_database(self, execution_id: str) -> Dict[str, Any]:
        """Get execution details from database"""
        try:
            with self.db_connection.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(
                    "SELECT * FROM workflow_executions WHERE execution_id = %s",
                    (execution_id,)
                )
                result = cursor.fetchone()
                
                if result:
                    return {
                        "execution_id": result["execution_id"],
                        "workflow_id": result["workflow_id"],
                        "status": result["status"],
                        "start_time": result["start_time"].isoformat() if result["start_time"] else None,
                        "end_time": result["end_time"].isoformat() if result["end_time"] else None,
                        "step_executions": json.loads(result["step_executions"]),
                        "error_message": result["error_message"]
                    }
                else:
                    raise ValueError(f"Execution not found: {execution_id}")
        
        except Exception as e:
            self.logger.error(f"Failed to get execution from database: {str(e)}")
            raise
    
    async def cancel_workflow_execution(self, execution_id: str) -> bool:
        """Cancel a running workflow execution"""
        if execution_id in self.active_executions:
            execution = self.active_executions[execution_id]
            execution.status = WorkflowStatus.CANCELLED
            execution.end_time = datetime.now()
            
            await self._save_execution_results(execution)
            self._update_workflow_metrics(execution)
            
            self.logger.info(f"Cancelled workflow execution: {execution_id}")
            return True
        
        return False
    
    def get_engine_metrics(self) -> Dict[str, Any]:
        """Get workflow engine metrics"""
        return {
            **self.execution_metrics,
            "active_executions": len(self.active_executions),
            "workflow_definitions": len(self.workflow_definitions),
            "engine_status": "running" if self.running else "stopped"
        }


class WorkflowScheduler:
    """Scheduler for time-based workflow triggers"""
    
    def __init__(self, workflow_engine: WorkflowEngine):
        self.workflow_engine = workflow_engine
        self.scheduler = schedule
        self.running = False
        self.logger = logging.getLogger("WorkflowScheduler")
    
    async def start(self):
        """Start the scheduler"""
        self.running = True
        
        # Schedule workflow checks
        await self._setup_scheduled_workflows()
        
        # Start scheduler loop
        asyncio.create_task(self._scheduler_loop())
        
        self.logger.info("Workflow Scheduler started")
    
    async def stop(self):
        """Stop the scheduler"""
        self.running = False
        self.scheduler.clear()
        self.logger.info("Workflow Scheduler stopped")
    
    async def _setup_scheduled_workflows(self):
        """Setup scheduled workflows"""
        for workflow_def in self.workflow_engine.workflow_definitions.values():
            for trigger in workflow_def.triggers:
                if trigger.trigger_type == TriggerType.SCHEDULED:
                    await self._schedule_workflow(workflow_def, trigger)
    
    async def _schedule_workflow(self, workflow_def: WorkflowDefinition, trigger: WorkflowTrigger):
        """Schedule a workflow based on trigger configuration"""
        schedule_config = trigger.trigger_config
        
        if schedule_config.get("type") == "cron":
            # Handle cron-style scheduling
            await self._schedule_cron_workflow(workflow_def, trigger, schedule_config)
        elif schedule_config.get("type") == "interval":
            # Handle interval-based scheduling
            await self._schedule_interval_workflow(workflow_def, trigger, schedule_config)
    
    async def _schedule_cron_workflow(self, 
                                    workflow_def: WorkflowDefinition,
                                    trigger: WorkflowTrigger,
                                    schedule_config: Dict[str, Any]):
        """Schedule workflow using cron expression"""
        # This would implement cron scheduling
        # For now, use simple daily scheduling as example
        self.scheduler.every().day.at(schedule_config.get("time", "09:00")).do(
            self._trigger_scheduled_workflow,
            workflow_def.workflow_id,
            trigger.trigger_id
        )
    
    async def _schedule_interval_workflow(self,
                                        workflow_def: WorkflowDefinition,
                                        trigger: WorkflowTrigger,
                                        schedule_config: Dict[str, Any]):
        """Schedule workflow using interval"""
        interval_minutes = schedule_config.get("interval_minutes", 60)
        
        self.scheduler.every(interval_minutes).minutes.do(
            self._trigger_scheduled_workflow,
            workflow_def.workflow_id,
            trigger.trigger_id
        )
    
    def _trigger_scheduled_workflow(self, workflow_id: str, trigger_id: str):
        """Trigger a scheduled workflow"""
        asyncio.create_task(
            self.workflow_engine.start_workflow_execution(
                workflow_id,
                {"trigger_id": trigger_id, "trigger_type": "scheduled"}
            )
        )
    
    async def _scheduler_loop(self):
        """Main scheduler loop"""
        while self.running:
            self.scheduler.run_pending()
            await asyncio.sleep(60)  # Check every minute


class WorkflowBuilder:
    """Builder for creating workflow definitions"""
    
    def __init__(self, workflow_engine: WorkflowEngine):
        self.workflow_engine = workflow_engine
        self.logger = logging.getLogger("WorkflowBuilder")
    
    def create_revenue_generation_workflow(self) -> WorkflowDefinition:
        """Create a comprehensive revenue generation workflow"""
        steps = [
            WorkflowStep(
                step_id="lead_generation",
                step_name="Generate Leads",
                agent_id="revenue_generation_agent",
                task_type="lead_generation",
                parameters={
                    "target_criteria": {
                        "company_size": "10+",
                        "budget_range": "5000-50000"
                    },
                    "sources": ["website", "social_media", "referrals"]
                },
                timeout_seconds=1800,
                success_criteria={"min_leads": 10}
            ),
            WorkflowStep(
                step_id="lead_scoring",
                step_name="Score Generated Leads",
                agent_id="revenue_generation_agent",
                task_type="lead_scoring",
                parameters={
                    "leads": "${lead_generation.result.qualified_leads}"
                },
                dependencies=["lead_generation"],
                timeout_seconds=600
            ),
            WorkflowStep(
                step_id="content_creation",
                step_name="Create Follow-up Content",
                agent_id="content_marketing_agent",
                task_type="content_creation",
                parameters={
                    "type": "email",
                    "target_audience": "qualified_leads",
                    "topic": "value_proposition"
                },
                dependencies=["lead_scoring"],
                parallel_execution=True,
                timeout_seconds=1200
            ),
            WorkflowStep(
                step_id="sales_automation",
                step_name="Automate Sales Process",
                agent_id="revenue_generation_agent",
                task_type="sales_automation",
                parameters={
                    "leads": "${lead_scoring.result.scored_leads}",
                    "automation_type": "email_sequence"
                },
                dependencies=["lead_scoring", "content_creation"],
                timeout_seconds=900
            )
        ]
        
        triggers = [
            WorkflowTrigger(
                trigger_id="daily_revenue_trigger",
                trigger_type=TriggerType.SCHEDULED,
                trigger_config={
                    "type": "cron",
                    "time": "09:00"
                }
            ),
            WorkflowTrigger(
                trigger_id="lead_threshold_trigger",
                trigger_type=TriggerType.CONDITION_BASED,
                trigger_config={
                    "condition": "lead_count < 50"
                }
            )
        ]
        
        return WorkflowDefinition(
            workflow_id="revenue_generation_workflow",
            workflow_name="Daily Revenue Generation",
            workflow_type=WorkflowType.REVENUE_GENERATION,
            description="Automated daily revenue generation workflow including lead generation, scoring, content creation, and sales automation",
            version="1.0",
            steps=steps,
            triggers=triggers,
            priority=WorkflowPriority.HIGH,
            timeout_seconds=7200,
            success_criteria={
                "min_qualified_leads": 5,
                "min_automation_actions": 10
            },
            failure_handling={
                "retry_enabled": True,
                "notification_enabled": True,
                "rollback_enabled": False
            }
        )
    
    def create_content_marketing_workflow(self) -> WorkflowDefinition:
        """Create a comprehensive content marketing workflow"""
        steps = [
            WorkflowStep(
                step_id="content_planning",
                step_name="Plan Content Calendar",
                agent_id="content_marketing_agent",
                task_type="content_planning",
                parameters={
                    "time_period": "weekly",
                    "content_types": ["blog_post", "social_media", "email"],
                    "target_audiences": ["business", "technical"]
                },
                timeout_seconds=1800
            ),
            WorkflowStep(
                step_id="blog_content_creation",
                step_name="Create Blog Content",
                agent_id="content_marketing_agent",
                task_type="content_creation",
                parameters={
                    "type": "blog_post",
                    "topic": "${content_planning.result.blog_topics[0]}",
                    "word_count": 1500
                },
                dependencies=["content_planning"],
                timeout_seconds=2400
            ),
            WorkflowStep(
                step_id="social_content_creation",
                step_name="Create Social Media Content",
                agent_id="content_marketing_agent",
                task_type="content_creation",
                parameters={
                    "type": "social_media",
                    "topic": "${content_planning.result.social_topics[0]}",
                    "platform": "linkedin"
                },
                dependencies=["content_planning"],
                parallel_execution=True,
                timeout_seconds=900
            ),
            WorkflowStep(
                step_id="content_optimization",
                step_name="Optimize Content for SEO",
                agent_id="content_marketing_agent",
                task_type="content_optimization",
                parameters={
                    "content_id": "${blog_content_creation.result.content_id}",
                    "goals": ["improve_seo", "increase_engagement"]
                },
                dependencies=["blog_content_creation"],
                timeout_seconds=1200
            ),
            WorkflowStep(
                step_id="content_distribution",
                step_name="Distribute Content",
                agent_id="content_marketing_agent",
                task_type="content_distribution",
                parameters={
                    "content_id": "${content_optimization.result.optimized_content_id}",
                    "channels": ["website", "social_media", "email"]
                },
                dependencies=["content_optimization", "social_content_creation"],
                timeout_seconds=1800
            )
        ]
        
        triggers = [
            WorkflowTrigger(
                trigger_id="weekly_content_trigger",
                trigger_type=TriggerType.SCHEDULED,
                trigger_config={
                    "type": "cron",
                    "day": "monday",
                    "time": "08:00"
                }
            )
        ]
        
        return WorkflowDefinition(
            workflow_id="content_marketing_workflow",
            workflow_name="Weekly Content Marketing",
            workflow_type=WorkflowType.CONTENT_CREATION,
            description="Automated weekly content marketing workflow including planning, creation, optimization, and distribution",
            version="1.0",
            steps=steps,
            triggers=triggers,
            priority=WorkflowPriority.MEDIUM,
            timeout_seconds=10800,
            success_criteria={
                "content_pieces_created": 3,
                "distribution_channels": 3
            }
        )
    
    def create_customer_journey_workflow(self) -> WorkflowDefinition:
        """Create a customer journey automation workflow"""
        steps = [
            WorkflowStep(
                step_id="lead_qualification",
                step_name="Qualify New Lead",
                agent_id="revenue_generation_agent",
                task_type="lead_scoring",
                parameters={
                    "leads": ["${trigger_data.lead}"]
                },
                timeout_seconds=300
            ),
            WorkflowStep(
                step_id="personalized_content",
                step_name="Create Personalized Content",
                agent_id="content_marketing_agent",
                task_type="content_creation",
                parameters={
                    "type": "email",
                    "personalization": "${lead_qualification.result.lead_profile}",
                    "template": "welcome_sequence"
                },
                dependencies=["lead_qualification"],
                timeout_seconds=900
            ),
            WorkflowStep(
                step_id="customer_onboarding",
                step_name="Initiate Customer Onboarding",
                agent_id="customer_success_agent",
                task_type="onboarding_automation",
                parameters={
                    "customer_data": "${lead_qualification.result}",
                    "onboarding_type": "standard"
                },
                dependencies=["lead_qualification"],
                conditions={"qualification": "hot"},
                timeout_seconds=1800
            ),
            WorkflowStep(
                step_id="follow_up_scheduling",
                step_name="Schedule Follow-up Actions",
                agent_id="revenue_generation_agent",
                task_type="sales_automation",
                parameters={
                    "leads": ["${trigger_data.lead}"],
                    "automation_type": "task_assignment",
                    "qualification": "${lead_qualification.result.qualification}"
                },
                dependencies=["lead_qualification", "personalized_content"],
                timeout_seconds=600
            )
        ]
        
        triggers = [
            WorkflowTrigger(
                trigger_id="new_lead_trigger",
                trigger_type=TriggerType.EVENT_DRIVEN,
                trigger_config={
                    "event_type": "lead.generated"
                }
            )
        ]
        
        return WorkflowDefinition(
            workflow_id="customer_journey_workflow",
            workflow_name="Automated Customer Journey",
            workflow_type=WorkflowType.CUSTOMER_JOURNEY,
            description="Automated customer journey workflow triggered by new lead generation",
            version="1.0",
            steps=steps,
            triggers=triggers,
            priority=WorkflowPriority.HIGH,
            timeout_seconds=3600
        )


# Database schema for workflow management
WORKFLOW_SCHEMA = """
CREATE TABLE IF NOT EXISTS workflow_definitions (
    workflow_id VARCHAR(255) PRIMARY KEY,
    workflow_name VARCHAR(255) NOT NULL,
    workflow_type VARCHAR(50) NOT NULL,
    description TEXT,
    version VARCHAR(50) NOT NULL,
    steps JSONB NOT NULL,
    triggers JSONB NOT NULL,
    priority INTEGER DEFAULT 3,
    timeout_seconds INTEGER DEFAULT 7200,
    retry_policy JSONB DEFAULT '{}',
    success_criteria JSONB DEFAULT '{}',
    failure_handling JSONB DEFAULT '{}',
    metadata JSONB DEFAULT '{}',
    enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS workflow_executions (
    execution_id VARCHAR(255) PRIMARY KEY,
    workflow_id VARCHAR(255) NOT NULL,
    status VARCHAR(50) NOT NULL,
    trigger_data JSONB DEFAULT '{}',
    step_executions JSONB DEFAULT '{}',
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    error_message TEXT,
    result_data JSONB DEFAULT '{}',
    metrics JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (workflow_id) REFERENCES workflow_definitions(workflow_id)
);

CREATE INDEX IF NOT EXISTS idx_workflow_executions_workflow_id ON workflow_executions(workflow_id);
CREATE INDEX IF NOT EXISTS idx_workflow_executions_status ON workflow_executions(status);
CREATE INDEX IF NOT EXISTS idx_workflow_executions_start_time ON workflow_executions(start_time);
CREATE INDEX IF NOT EXISTS idx_workflow_definitions_type ON workflow_definitions(workflow_type);
CREATE INDEX IF NOT EXISTS idx_workflow_definitions_enabled ON workflow_definitions(enabled);
"""


def setup_workflow_database(db_connection):
    """Setup database schema for workflow management"""
    try:
        with db_connection.cursor() as cursor:
            cursor.execute(WORKFLOW_SCHEMA)
        db_connection.commit()
        print("Workflow database schema created successfully")
    except Exception as e:
        print(f"Failed to create workflow database schema: {str(e)}")


if __name__ == "__main__":
    # Example usage and testing
    import redis
    import psycopg2
    
    async def main():
        # Setup connections
        redis_client = redis.Redis(host='localhost', port=6379, db=0)
        db_connection = psycopg2.connect(
            host="localhost",
            database="aiagent",
            user="aiagent",
            password="password"
        )
        
        # Setup database
        setup_workflow_database(db_connection)
        
        print("Comprehensive Workflow Automation Framework loaded successfully")
        print("Ready for workflow definition and execution")
    
    asyncio.run(main())

