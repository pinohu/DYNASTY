#!/usr/bin/env python3
"""
AI Agent Life Operating System - Comprehensive Monitoring System

This monitoring system provides complete visibility into the performance, health, and
effectiveness of all 15 AI agents, 209 tool integrations, and business workflows.
The system includes real-time monitoring, alerting, performance analytics, and
automated optimization capabilities.

Author: Manus AI
Date: July 8, 2025
Version: 1.0
"""

import asyncio
import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Union, Callable, Set, Tuple
import uuid
import threading
from concurrent.futures import ThreadPoolExecutor
import statistics
import numpy as np
from collections import defaultdict, deque

import redis
import psycopg2
from psycopg2.extras import RealDictCursor
import prometheus_client
from prometheus_client import Counter, Histogram, Gauge, Summary
import grafana_api
import elasticsearch
from elasticsearch import Elasticsearch
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import requests
import yaml
from pathlib import Path


class AlertSeverity(Enum):
    """Alert severity levels"""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class MetricType(Enum):
    """Types of metrics"""
    COUNTER = "counter"
    GAUGE = "gauge"
    HISTOGRAM = "histogram"
    SUMMARY = "summary"


class MonitoringStatus(Enum):
    """Monitoring system status"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    MAINTENANCE = "maintenance"


@dataclass
class MetricDefinition:
    """Definition of a monitoring metric"""
    metric_name: str
    metric_type: MetricType
    description: str
    labels: List[str] = field(default_factory=list)
    unit: str = ""
    aggregation_method: str = "avg"
    retention_days: int = 30


@dataclass
class AlertRule:
    """Alert rule configuration"""
    rule_id: str
    rule_name: str
    metric_name: str
    condition: str  # e.g., "> 0.8", "< 100", "== 0"
    threshold_value: float
    severity: AlertSeverity
    duration_minutes: int = 5
    notification_channels: List[str] = field(default_factory=list)
    enabled: bool = True
    description: str = ""


@dataclass
class Alert:
    """Alert instance"""
    alert_id: str
    rule_id: str
    alert_name: str
    severity: AlertSeverity
    message: str
    metric_value: float
    threshold_value: float
    triggered_at: datetime
    resolved_at: Optional[datetime] = None
    status: str = "active"  # active, resolved, suppressed
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PerformanceMetrics:
    """Performance metrics for system components"""
    component_id: str
    component_type: str
    cpu_usage: float = 0.0
    memory_usage: float = 0.0
    disk_usage: float = 0.0
    network_io: float = 0.0
    response_time: float = 0.0
    error_rate: float = 0.0
    throughput: float = 0.0
    availability: float = 100.0
    last_updated: datetime = field(default_factory=datetime.now)


class MetricsCollector:
    """Collects metrics from various system components"""
    
    def __init__(self, 
                 redis_client: redis.Redis,
                 db_connection,
                 elasticsearch_client: Elasticsearch):
        
        self.redis_client = redis_client
        self.db_connection = db_connection
        self.elasticsearch_client = elasticsearch_client
        self.logger = logging.getLogger("MetricsCollector")
        
        # Prometheus metrics
        self.prometheus_metrics = {}
        self._initialize_prometheus_metrics()
        
        # Metric definitions
        self.metric_definitions: Dict[str, MetricDefinition] = {}
        self._load_metric_definitions()
        
        # Collection intervals
        self.collection_intervals = {
            "system_metrics": 30,  # seconds
            "agent_metrics": 60,
            "workflow_metrics": 120,
            "business_metrics": 300
        }
        
        # Running state
        self.running = False
        self.collection_tasks = {}
    
    def _initialize_prometheus_metrics(self):
        """Initialize Prometheus metrics"""
        # Agent performance metrics
        self.prometheus_metrics['agent_task_duration'] = Histogram(
            'agent_task_duration_seconds',
            'Time spent processing agent tasks',
            ['agent_id', 'task_type']
        )
        
        self.prometheus_metrics['agent_task_total'] = Counter(
            'agent_task_total',
            'Total number of agent tasks processed',
            ['agent_id', 'task_type', 'status']
        )
        
        self.prometheus_metrics['agent_memory_usage'] = Gauge(
            'agent_memory_usage_bytes',
            'Memory usage by agent',
            ['agent_id']
        )
        
        self.prometheus_metrics['agent_cpu_usage'] = Gauge(
            'agent_cpu_usage_percent',
            'CPU usage by agent',
            ['agent_id']
        )
        
        # Workflow metrics
        self.prometheus_metrics['workflow_execution_duration'] = Histogram(
            'workflow_execution_duration_seconds',
            'Time spent executing workflows',
            ['workflow_id', 'workflow_type']
        )
        
        self.prometheus_metrics['workflow_execution_total'] = Counter(
            'workflow_execution_total',
            'Total number of workflow executions',
            ['workflow_id', 'status']
        )
        
        # Business metrics
        self.prometheus_metrics['revenue_generated'] = Counter(
            'revenue_generated_total',
            'Total revenue generated',
            ['source', 'currency']
        )
        
        self.prometheus_metrics['leads_generated'] = Counter(
            'leads_generated_total',
            'Total leads generated',
            ['source', 'qualification']
        )
        
        self.prometheus_metrics['content_created'] = Counter(
            'content_created_total',
            'Total content pieces created',
            ['content_type', 'channel']
        )
        
        # System health metrics
        self.prometheus_metrics['system_health_score'] = Gauge(
            'system_health_score',
            'Overall system health score',
            ['component']
        )
        
        self.prometheus_metrics['integration_status'] = Gauge(
            'integration_status',
            'Status of tool integrations',
            ['tool_id', 'integration_type']
        )
    
    def _load_metric_definitions(self):
        """Load metric definitions from configuration"""
        # This would load from a configuration file or database
        # For now, define core metrics programmatically
        
        core_metrics = [
            MetricDefinition(
                metric_name="agent_response_time",
                metric_type=MetricType.HISTOGRAM,
                description="Agent response time in seconds",
                labels=["agent_id", "task_type"],
                unit="seconds"
            ),
            MetricDefinition(
                metric_name="workflow_success_rate",
                metric_type=MetricType.GAUGE,
                description="Workflow success rate percentage",
                labels=["workflow_id"],
                unit="percent"
            ),
            MetricDefinition(
                metric_name="tool_integration_health",
                metric_type=MetricType.GAUGE,
                description="Tool integration health score",
                labels=["tool_id"],
                unit="score"
            ),
            MetricDefinition(
                metric_name="business_kpi_value",
                metric_type=MetricType.GAUGE,
                description="Business KPI values",
                labels=["kpi_name", "time_period"],
                unit="value"
            )
        ]
        
        for metric_def in core_metrics:
            self.metric_definitions[metric_def.metric_name] = metric_def
    
    async def start_collection(self):
        """Start metrics collection"""
        self.running = True
        self.logger.info("Starting metrics collection")
        
        # Start collection tasks for different metric types
        for metric_type, interval in self.collection_intervals.items():
            task = asyncio.create_task(
                self._collection_loop(metric_type, interval)
            )
            self.collection_tasks[metric_type] = task
        
        # Start Prometheus metrics server
        prometheus_client.start_http_server(8000)
        self.logger.info("Prometheus metrics server started on port 8000")
    
    async def stop_collection(self):
        """Stop metrics collection"""
        self.running = False
        
        # Cancel all collection tasks
        for task in self.collection_tasks.values():
            task.cancel()
        
        # Wait for tasks to complete
        await asyncio.gather(*self.collection_tasks.values(), return_exceptions=True)
        
        self.logger.info("Metrics collection stopped")
    
    async def _collection_loop(self, metric_type: str, interval: int):
        """Main collection loop for specific metric type"""
        while self.running:
            try:
                if metric_type == "system_metrics":
                    await self._collect_system_metrics()
                elif metric_type == "agent_metrics":
                    await self._collect_agent_metrics()
                elif metric_type == "workflow_metrics":
                    await self._collect_workflow_metrics()
                elif metric_type == "business_metrics":
                    await self._collect_business_metrics()
                
                await asyncio.sleep(interval)
                
            except Exception as e:
                self.logger.error(f"Error in {metric_type} collection: {str(e)}")
                await asyncio.sleep(interval)
    
    async def _collect_system_metrics(self):
        """Collect system-level metrics"""
        try:
            # Collect infrastructure metrics
            system_metrics = await self._get_system_performance()
            
            # Update Prometheus metrics
            for component, metrics in system_metrics.items():
                self.prometheus_metrics['agent_cpu_usage'].labels(
                    agent_id=component
                ).set(metrics.get('cpu_usage', 0))
                
                self.prometheus_metrics['agent_memory_usage'].labels(
                    agent_id=component
                ).set(metrics.get('memory_usage', 0))
            
            # Store in time series database
            await self._store_metrics("system", system_metrics)
            
        except Exception as e:
            self.logger.error(f"Failed to collect system metrics: {str(e)}")
    
    async def _collect_agent_metrics(self):
        """Collect agent performance metrics"""
        try:
            # Get agent metrics from Redis
            agent_metrics = {}
            
            # Collect metrics for each agent
            agent_keys = self.redis_client.keys("agent_metrics:*")
            for key in agent_keys:
                agent_id = key.decode().split(":")[-1]
                metrics_data = self.redis_client.hgetall(key)
                
                if metrics_data:
                    agent_metrics[agent_id] = {
                        k.decode(): float(v.decode()) if v.decode().replace('.', '').isdigit() else v.decode()
                        for k, v in metrics_data.items()
                    }
            
            # Update Prometheus metrics
            for agent_id, metrics in agent_metrics.items():
                # Update task counters
                tasks_completed = metrics.get('tasks_completed', 0)
                tasks_failed = metrics.get('tasks_failed', 0)
                
                # Calculate success rate
                total_tasks = tasks_completed + tasks_failed
                success_rate = tasks_completed / total_tasks if total_tasks > 0 else 0
                
                # Update health score
                health_score = self._calculate_agent_health_score(metrics)
                self.prometheus_metrics['system_health_score'].labels(
                    component=agent_id
                ).set(health_score)
            
            # Store in time series database
            await self._store_metrics("agents", agent_metrics)
            
        except Exception as e:
            self.logger.error(f"Failed to collect agent metrics: {str(e)}")
    
    async def _collect_workflow_metrics(self):
        """Collect workflow execution metrics"""
        try:
            # Get workflow metrics from database
            workflow_metrics = await self._get_workflow_performance()
            
            # Update Prometheus metrics
            for workflow_id, metrics in workflow_metrics.items():
                success_rate = metrics.get('success_rate', 0)
                avg_duration = metrics.get('avg_duration', 0)
                
                # Update workflow success rate
                self.prometheus_metrics['system_health_score'].labels(
                    component=f"workflow_{workflow_id}"
                ).set(success_rate * 100)
            
            # Store in time series database
            await self._store_metrics("workflows", workflow_metrics)
            
        except Exception as e:
            self.logger.error(f"Failed to collect workflow metrics: {str(e)}")
    
    async def _collect_business_metrics(self):
        """Collect business performance metrics"""
        try:
            # Calculate business KPIs
            business_metrics = await self._calculate_business_kpis()
            
            # Update Prometheus metrics
            for kpi_name, value in business_metrics.items():
                if isinstance(value, (int, float)):
                    self.prometheus_metrics['system_health_score'].labels(
                        component=f"business_{kpi_name}"
                    ).set(value)
            
            # Store in time series database
            await self._store_metrics("business", business_metrics)
            
        except Exception as e:
            self.logger.error(f"Failed to collect business metrics: {str(e)}")
    
    async def _get_system_performance(self) -> Dict[str, Dict[str, float]]:
        """Get system performance metrics"""
        # This would integrate with system monitoring tools
        # For now, return simulated metrics
        
        import psutil
        
        system_metrics = {
            "system": {
                "cpu_usage": psutil.cpu_percent(),
                "memory_usage": psutil.virtual_memory().percent,
                "disk_usage": psutil.disk_usage('/').percent,
                "network_io": sum(psutil.net_io_counters()[:2])
            }
        }
        
        return system_metrics
    
    async def _get_workflow_performance(self) -> Dict[str, Dict[str, float]]:
        """Get workflow performance metrics from database"""
        try:
            with self.db_connection.cursor(cursor_factory=RealDictCursor) as cursor:
                # Get workflow execution statistics
                cursor.execute("""
                    SELECT 
                        workflow_id,
                        COUNT(*) as total_executions,
                        COUNT(*) FILTER (WHERE status = 'completed') as successful_executions,
                        AVG(EXTRACT(EPOCH FROM (end_time - start_time))) as avg_duration,
                        MAX(start_time) as last_execution
                    FROM workflow_executions 
                    WHERE start_time >= NOW() - INTERVAL '24 hours'
                    GROUP BY workflow_id
                """)
                
                results = cursor.fetchall()
                
                workflow_metrics = {}
                for row in results:
                    workflow_id = row['workflow_id']
                    total = row['total_executions']
                    successful = row['successful_executions']
                    
                    workflow_metrics[workflow_id] = {
                        'total_executions': total,
                        'successful_executions': successful,
                        'success_rate': successful / total if total > 0 else 0,
                        'avg_duration': row['avg_duration'] or 0,
                        'last_execution': row['last_execution'].isoformat() if row['last_execution'] else None
                    }
                
                return workflow_metrics
        
        except Exception as e:
            self.logger.error(f"Failed to get workflow performance: {str(e)}")
            return {}
    
    async def _calculate_business_kpis(self) -> Dict[str, float]:
        """Calculate business KPIs"""
        try:
            # This would integrate with business data sources
            # For now, return simulated KPIs
            
            kpis = {
                "daily_revenue": 2500.0,
                "leads_generated": 15.0,
                "conversion_rate": 0.12,
                "customer_satisfaction": 4.2,
                "content_pieces_created": 8.0,
                "social_media_engagement": 0.05,
                "email_open_rate": 0.25,
                "website_traffic": 1200.0
            }
            
            return kpis
        
        except Exception as e:
            self.logger.error(f"Failed to calculate business KPIs: {str(e)}")
            return {}
    
    def _calculate_agent_health_score(self, metrics: Dict[str, Any]) -> float:
        """Calculate overall health score for an agent"""
        try:
            # Factors for health score calculation
            success_rate = metrics.get('success_rate', 0)
            avg_response_time = metrics.get('average_execution_time', 0)
            error_rate = metrics.get('error_count', 0) / max(metrics.get('tasks_completed', 1), 1)
            uptime = min(metrics.get('uptime_hours', 0) / 24, 1)  # Normalize to 0-1
            
            # Weight factors
            health_score = (
                success_rate * 0.4 +
                (1 - min(avg_response_time / 60, 1)) * 0.3 +  # Penalize slow response
                (1 - min(error_rate, 1)) * 0.2 +
                uptime * 0.1
            ) * 100
            
            return max(0, min(100, health_score))
        
        except Exception as e:
            self.logger.error(f"Failed to calculate health score: {str(e)}")
            return 0.0
    
    async def _store_metrics(self, metric_category: str, metrics: Dict[str, Any]):
        """Store metrics in time series database"""
        try:
            timestamp = datetime.now()
            
            # Store in Elasticsearch for time series analysis
            for component_id, component_metrics in metrics.items():
                doc = {
                    "timestamp": timestamp,
                    "category": metric_category,
                    "component_id": component_id,
                    "metrics": component_metrics
                }
                
                index_name = f"metrics-{metric_category}-{timestamp.strftime('%Y-%m')}"
                
                await asyncio.get_event_loop().run_in_executor(
                    None,
                    lambda: self.elasticsearch_client.index(
                        index=index_name,
                        body=doc
                    )
                )
            
            # Also store in Redis for real-time access
            redis_key = f"metrics:{metric_category}:{int(timestamp.timestamp())}"
            self.redis_client.setex(
                redis_key,
                3600,  # 1 hour expiration
                json.dumps(metrics)
            )
            
        except Exception as e:
            self.logger.error(f"Failed to store metrics: {str(e)}")
    
    async def get_metrics(self, 
                         metric_category: str,
                         component_id: Optional[str] = None,
                         time_range: Optional[Tuple[datetime, datetime]] = None) -> Dict[str, Any]:
        """Retrieve metrics for analysis"""
        try:
            # Build Elasticsearch query
            query = {
                "bool": {
                    "must": [
                        {"term": {"category": metric_category}}
                    ]
                }
            }
            
            if component_id:
                query["bool"]["must"].append({"term": {"component_id": component_id}})
            
            if time_range:
                start_time, end_time = time_range
                query["bool"]["must"].append({
                    "range": {
                        "timestamp": {
                            "gte": start_time.isoformat(),
                            "lte": end_time.isoformat()
                        }
                    }
                })
            
            # Execute search
            search_body = {
                "query": query,
                "sort": [{"timestamp": {"order": "desc"}}],
                "size": 1000
            }
            
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.elasticsearch_client.search(
                    index=f"metrics-{metric_category}-*",
                    body=search_body
                )
            )
            
            # Process results
            metrics_data = []
            for hit in response['hits']['hits']:
                metrics_data.append(hit['_source'])
            
            return {"metrics": metrics_data, "total": len(metrics_data)}
        
        except Exception as e:
            self.logger.error(f"Failed to retrieve metrics: {str(e)}")
            return {"metrics": [], "total": 0}


class AlertManager:
    """Manages alerts and notifications"""
    
    def __init__(self, 
                 redis_client: redis.Redis,
                 db_connection,
                 metrics_collector: MetricsCollector):
        
        self.redis_client = redis_client
        self.db_connection = db_connection
        self.metrics_collector = metrics_collector
        self.logger = logging.getLogger("AlertManager")
        
        # Alert rules and active alerts
        self.alert_rules: Dict[str, AlertRule] = {}
        self.active_alerts: Dict[str, Alert] = {}
        
        # Notification channels
        self.notification_channels = {
            "email": self._send_email_notification,
            "slack": self._send_slack_notification,
            "webhook": self._send_webhook_notification
        }
        
        # Alert evaluation state
        self.running = False
        self.evaluation_interval = 60  # seconds
        
        # Load alert rules
        self._load_alert_rules()
    
    def _load_alert_rules(self):
        """Load alert rules from configuration"""
        # Define critical alert rules
        critical_rules = [
            AlertRule(
                rule_id="agent_high_error_rate",
                rule_name="Agent High Error Rate",
                metric_name="agent_error_rate",
                condition="> 0.1",
                threshold_value=0.1,
                severity=AlertSeverity.CRITICAL,
                duration_minutes=5,
                notification_channels=["email", "slack"],
                description="Agent error rate exceeds 10%"
            ),
            AlertRule(
                rule_id="workflow_failure_rate",
                rule_name="Workflow High Failure Rate",
                metric_name="workflow_failure_rate",
                condition="> 0.2",
                threshold_value=0.2,
                severity=AlertSeverity.HIGH,
                duration_minutes=10,
                notification_channels=["email"],
                description="Workflow failure rate exceeds 20%"
            ),
            AlertRule(
                rule_id="system_cpu_high",
                rule_name="High CPU Usage",
                metric_name="system_cpu_usage",
                condition="> 80",
                threshold_value=80.0,
                severity=AlertSeverity.MEDIUM,
                duration_minutes=15,
                notification_channels=["email"],
                description="System CPU usage exceeds 80%"
            ),
            AlertRule(
                rule_id="revenue_drop",
                rule_name="Revenue Drop",
                metric_name="daily_revenue",
                condition="< 1000",
                threshold_value=1000.0,
                severity=AlertSeverity.HIGH,
                duration_minutes=60,
                notification_channels=["email", "slack"],
                description="Daily revenue below $1000"
            ),
            AlertRule(
                rule_id="integration_failure",
                rule_name="Tool Integration Failure",
                metric_name="integration_health",
                condition="< 0.8",
                threshold_value=0.8,
                severity=AlertSeverity.MEDIUM,
                duration_minutes=5,
                notification_channels=["email"],
                description="Tool integration health below 80%"
            )
        ]
        
        for rule in critical_rules:
            self.alert_rules[rule.rule_id] = rule
    
    async def start_monitoring(self):
        """Start alert monitoring"""
        self.running = True
        self.logger.info("Starting alert monitoring")
        
        # Start alert evaluation loop
        asyncio.create_task(self._evaluation_loop())
    
    async def stop_monitoring(self):
        """Stop alert monitoring"""
        self.running = False
        self.logger.info("Alert monitoring stopped")
    
    async def _evaluation_loop(self):
        """Main alert evaluation loop"""
        while self.running:
            try:
                await self._evaluate_alert_rules()
                await self._check_alert_resolution()
                await asyncio.sleep(self.evaluation_interval)
                
            except Exception as e:
                self.logger.error(f"Error in alert evaluation: {str(e)}")
                await asyncio.sleep(self.evaluation_interval)
    
    async def _evaluate_alert_rules(self):
        """Evaluate all alert rules"""
        for rule in self.alert_rules.values():
            if rule.enabled:
                await self._evaluate_single_rule(rule)
    
    async def _evaluate_single_rule(self, rule: AlertRule):
        """Evaluate a single alert rule"""
        try:
            # Get current metric value
            metric_value = await self._get_metric_value(rule.metric_name)
            
            if metric_value is None:
                return
            
            # Evaluate condition
            condition_met = self._evaluate_condition(metric_value, rule.condition, rule.threshold_value)
            
            if condition_met:
                # Check if alert already exists
                existing_alert = self._find_existing_alert(rule.rule_id)
                
                if not existing_alert:
                    # Create new alert
                    alert = Alert(
                        alert_id=str(uuid.uuid4()),
                        rule_id=rule.rule_id,
                        alert_name=rule.rule_name,
                        severity=rule.severity,
                        message=f"{rule.description}. Current value: {metric_value}",
                        metric_value=metric_value,
                        threshold_value=rule.threshold_value,
                        triggered_at=datetime.now()
                    )
                    
                    # Check duration requirement
                    if await self._check_duration_requirement(rule, metric_value):
                        await self._trigger_alert(alert, rule)
                else:
                    # Update existing alert
                    existing_alert.metric_value = metric_value
                    existing_alert.message = f"{rule.description}. Current value: {metric_value}"
            
        except Exception as e:
            self.logger.error(f"Failed to evaluate rule {rule.rule_id}: {str(e)}")
    
    async def _get_metric_value(self, metric_name: str) -> Optional[float]:
        """Get current value for a metric"""
        try:
            # This would get the latest metric value from the time series database
            # For now, simulate metric values
            
            metric_values = {
                "agent_error_rate": 0.05,
                "workflow_failure_rate": 0.15,
                "system_cpu_usage": 75.0,
                "daily_revenue": 2500.0,
                "integration_health": 0.9
            }
            
            return metric_values.get(metric_name)
        
        except Exception as e:
            self.logger.error(f"Failed to get metric value for {metric_name}: {str(e)}")
            return None
    
    def _evaluate_condition(self, value: float, condition: str, threshold: float) -> bool:
        """Evaluate alert condition"""
        try:
            if condition.startswith(">"):
                return value > threshold
            elif condition.startswith("<"):
                return value < threshold
            elif condition.startswith("=="):
                return value == threshold
            elif condition.startswith("!="):
                return value != threshold
            elif condition.startswith(">="):
                return value >= threshold
            elif condition.startswith("<="):
                return value <= threshold
            else:
                return False
        
        except Exception as e:
            self.logger.error(f"Failed to evaluate condition: {str(e)}")
            return False
    
    def _find_existing_alert(self, rule_id: str) -> Optional[Alert]:
        """Find existing active alert for rule"""
        for alert in self.active_alerts.values():
            if alert.rule_id == rule_id and alert.status == "active":
                return alert
        return None
    
    async def _check_duration_requirement(self, rule: AlertRule, metric_value: float) -> bool:
        """Check if condition has been met for required duration"""
        # This would check if the condition has been consistently met
        # For now, assume duration requirement is met
        return True
    
    async def _trigger_alert(self, alert: Alert, rule: AlertRule):
        """Trigger a new alert"""
        try:
            # Add to active alerts
            self.active_alerts[alert.alert_id] = alert
            
            # Save to database
            await self._save_alert(alert)
            
            # Send notifications
            await self._send_notifications(alert, rule)
            
            self.logger.warning(f"Alert triggered: {alert.alert_name} - {alert.message}")
        
        except Exception as e:
            self.logger.error(f"Failed to trigger alert: {str(e)}")
    
    async def _save_alert(self, alert: Alert):
        """Save alert to database"""
        try:
            with self.db_connection.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO alerts (
                        alert_id, rule_id, alert_name, severity, message,
                        metric_value, threshold_value, triggered_at, status, metadata
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (
                    alert.alert_id,
                    alert.rule_id,
                    alert.alert_name,
                    alert.severity.value,
                    alert.message,
                    alert.metric_value,
                    alert.threshold_value,
                    alert.triggered_at,
                    alert.status,
                    json.dumps(alert.metadata)
                ))
            self.db_connection.commit()
        
        except Exception as e:
            self.logger.error(f"Failed to save alert: {str(e)}")
    
    async def _send_notifications(self, alert: Alert, rule: AlertRule):
        """Send alert notifications"""
        for channel in rule.notification_channels:
            if channel in self.notification_channels:
                try:
                    await self.notification_channels[channel](alert, rule)
                except Exception as e:
                    self.logger.error(f"Failed to send {channel} notification: {str(e)}")
    
    async def _send_email_notification(self, alert: Alert, rule: AlertRule):
        """Send email notification"""
        try:
            # Email configuration (would be loaded from config)
            smtp_server = "smtp.gmail.com"
            smtp_port = 587
            email_user = "alerts@yourdomain.com"
            email_password = "your_email_password"
            recipient = "admin@yourdomain.com"
            
            # Create email message
            msg = MIMEMultipart()
            msg['From'] = email_user
            msg['To'] = recipient
            msg['Subject'] = f"[{alert.severity.value.upper()}] {alert.alert_name}"
            
            body = f"""
            Alert: {alert.alert_name}
            Severity: {alert.severity.value}
            Message: {alert.message}
            Metric Value: {alert.metric_value}
            Threshold: {alert.threshold_value}
            Triggered At: {alert.triggered_at}
            
            Please investigate and take appropriate action.
            """
            
            msg.attach(MIMEText(body, 'plain'))
            
            # Send email
            server = smtplib.SMTP(smtp_server, smtp_port)
            server.starttls()
            server.login(email_user, email_password)
            text = msg.as_string()
            server.sendmail(email_user, recipient, text)
            server.quit()
            
            self.logger.info(f"Email notification sent for alert: {alert.alert_id}")
        
        except Exception as e:
            self.logger.error(f"Failed to send email notification: {str(e)}")
    
    async def _send_slack_notification(self, alert: Alert, rule: AlertRule):
        """Send Slack notification"""
        try:
            # Slack webhook URL (would be loaded from config)
            webhook_url = "https://hooks.slack.com/services/YOUR/SLACK/WEBHOOK"
            
            # Create Slack message
            color = {
                AlertSeverity.CRITICAL: "danger",
                AlertSeverity.HIGH: "warning",
                AlertSeverity.MEDIUM: "warning",
                AlertSeverity.LOW: "good",
                AlertSeverity.INFO: "good"
            }.get(alert.severity, "warning")
            
            payload = {
                "attachments": [
                    {
                        "color": color,
                        "title": f"[{alert.severity.value.upper()}] {alert.alert_name}",
                        "text": alert.message,
                        "fields": [
                            {
                                "title": "Metric Value",
                                "value": str(alert.metric_value),
                                "short": True
                            },
                            {
                                "title": "Threshold",
                                "value": str(alert.threshold_value),
                                "short": True
                            },
                            {
                                "title": "Triggered At",
                                "value": alert.triggered_at.strftime("%Y-%m-%d %H:%M:%S"),
                                "short": False
                            }
                        ]
                    }
                ]
            }
            
            # Send to Slack
            response = requests.post(webhook_url, json=payload)
            response.raise_for_status()
            
            self.logger.info(f"Slack notification sent for alert: {alert.alert_id}")
        
        except Exception as e:
            self.logger.error(f"Failed to send Slack notification: {str(e)}")
    
    async def _send_webhook_notification(self, alert: Alert, rule: AlertRule):
        """Send webhook notification"""
        try:
            # Webhook URL (would be loaded from config)
            webhook_url = "https://your-webhook-endpoint.com/alerts"
            
            # Create webhook payload
            payload = {
                "alert_id": alert.alert_id,
                "rule_id": alert.rule_id,
                "alert_name": alert.alert_name,
                "severity": alert.severity.value,
                "message": alert.message,
                "metric_value": alert.metric_value,
                "threshold_value": alert.threshold_value,
                "triggered_at": alert.triggered_at.isoformat(),
                "status": alert.status
            }
            
            # Send webhook
            response = requests.post(
                webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=30
            )
            response.raise_for_status()
            
            self.logger.info(f"Webhook notification sent for alert: {alert.alert_id}")
        
        except Exception as e:
            self.logger.error(f"Failed to send webhook notification: {str(e)}")
    
    async def _check_alert_resolution(self):
        """Check if active alerts should be resolved"""
        for alert in list(self.active_alerts.values()):
            if alert.status == "active":
                # Get current metric value
                current_value = await self._get_metric_value(
                    self.alert_rules[alert.rule_id].metric_name
                )
                
                if current_value is not None:
                    rule = self.alert_rules[alert.rule_id]
                    condition_met = self._evaluate_condition(
                        current_value, rule.condition, rule.threshold_value
                    )
                    
                    if not condition_met:
                        # Resolve alert
                        await self._resolve_alert(alert)
    
    async def _resolve_alert(self, alert: Alert):
        """Resolve an active alert"""
        try:
            alert.status = "resolved"
            alert.resolved_at = datetime.now()
            
            # Update in database
            with self.db_connection.cursor() as cursor:
                cursor.execute("""
                    UPDATE alerts 
                    SET status = %s, resolved_at = %s 
                    WHERE alert_id = %s
                """, (alert.status, alert.resolved_at, alert.alert_id))
            self.db_connection.commit()
            
            # Remove from active alerts
            if alert.alert_id in self.active_alerts:
                del self.active_alerts[alert.alert_id]
            
            self.logger.info(f"Alert resolved: {alert.alert_name}")
        
        except Exception as e:
            self.logger.error(f"Failed to resolve alert: {str(e)}")
    
    def get_active_alerts(self) -> List[Alert]:
        """Get list of active alerts"""
        return list(self.active_alerts.values())
    
    async def get_alert_history(self, 
                              hours: int = 24,
                              severity: Optional[AlertSeverity] = None) -> List[Dict[str, Any]]:
        """Get alert history"""
        try:
            with self.db_connection.cursor(cursor_factory=RealDictCursor) as cursor:
                query = """
                    SELECT * FROM alerts 
                    WHERE triggered_at >= NOW() - INTERVAL '%s hours'
                """
                params = [hours]
                
                if severity:
                    query += " AND severity = %s"
                    params.append(severity.value)
                
                query += " ORDER BY triggered_at DESC"
                
                cursor.execute(query, params)
                results = cursor.fetchall()
                
                return [dict(row) for row in results]
        
        except Exception as e:
            self.logger.error(f"Failed to get alert history: {str(e)}")
            return []


class PerformanceAnalyzer:
    """Analyzes system performance and provides optimization recommendations"""
    
    def __init__(self, 
                 metrics_collector: MetricsCollector,
                 alert_manager: AlertManager):
        
        self.metrics_collector = metrics_collector
        self.alert_manager = alert_manager
        self.logger = logging.getLogger("PerformanceAnalyzer")
        
        # Analysis configuration
        self.analysis_intervals = {
            "real_time": 300,    # 5 minutes
            "hourly": 3600,      # 1 hour
            "daily": 86400,      # 24 hours
            "weekly": 604800     # 7 days
        }
        
        # Performance baselines
        self.performance_baselines = {}
        
        # Running state
        self.running = False
    
    async def start_analysis(self):
        """Start performance analysis"""
        self.running = True
        self.logger.info("Starting performance analysis")
        
        # Start analysis tasks
        for analysis_type, interval in self.analysis_intervals.items():
            asyncio.create_task(self._analysis_loop(analysis_type, interval))
    
    async def stop_analysis(self):
        """Stop performance analysis"""
        self.running = False
        self.logger.info("Performance analysis stopped")
    
    async def _analysis_loop(self, analysis_type: str, interval: int):
        """Main analysis loop"""
        while self.running:
            try:
                if analysis_type == "real_time":
                    await self._real_time_analysis()
                elif analysis_type == "hourly":
                    await self._hourly_analysis()
                elif analysis_type == "daily":
                    await self._daily_analysis()
                elif analysis_type == "weekly":
                    await self._weekly_analysis()
                
                await asyncio.sleep(interval)
                
            except Exception as e:
                self.logger.error(f"Error in {analysis_type} analysis: {str(e)}")
                await asyncio.sleep(interval)
    
    async def _real_time_analysis(self):
        """Perform real-time performance analysis"""
        try:
            # Analyze current system performance
            current_metrics = await self._get_current_performance_snapshot()
            
            # Check for performance anomalies
            anomalies = await self._detect_performance_anomalies(current_metrics)
            
            if anomalies:
                await self._handle_performance_anomalies(anomalies)
            
            # Update performance baselines
            await self._update_performance_baselines(current_metrics)
            
        except Exception as e:
            self.logger.error(f"Real-time analysis failed: {str(e)}")
    
    async def _hourly_analysis(self):
        """Perform hourly performance analysis"""
        try:
            # Get hourly metrics
            end_time = datetime.now()
            start_time = end_time - timedelta(hours=1)
            
            hourly_metrics = await self._get_performance_metrics(start_time, end_time)
            
            # Analyze trends
            trends = await self._analyze_performance_trends(hourly_metrics)
            
            # Generate recommendations
            recommendations = await self._generate_optimization_recommendations(trends)
            
            if recommendations:
                await self._store_recommendations(recommendations, "hourly")
            
        except Exception as e:
            self.logger.error(f"Hourly analysis failed: {str(e)}")
    
    async def _daily_analysis(self):
        """Perform daily performance analysis"""
        try:
            # Get daily metrics
            end_time = datetime.now()
            start_time = end_time - timedelta(days=1)
            
            daily_metrics = await self._get_performance_metrics(start_time, end_time)
            
            # Generate daily performance report
            report = await self._generate_daily_report(daily_metrics)
            
            # Store report
            await self._store_performance_report(report, "daily")
            
        except Exception as e:
            self.logger.error(f"Daily analysis failed: {str(e)}")
    
    async def _weekly_analysis(self):
        """Perform weekly performance analysis"""
        try:
            # Get weekly metrics
            end_time = datetime.now()
            start_time = end_time - timedelta(weeks=1)
            
            weekly_metrics = await self._get_performance_metrics(start_time, end_time)
            
            # Generate comprehensive analysis
            analysis = await self._generate_comprehensive_analysis(weekly_metrics)
            
            # Store analysis
            await self._store_performance_report(analysis, "weekly")
            
        except Exception as e:
            self.logger.error(f"Weekly analysis failed: {str(e)}")
    
    async def _get_current_performance_snapshot(self) -> Dict[str, Any]:
        """Get current performance snapshot"""
        try:
            # Get latest metrics from all categories
            system_metrics = await self.metrics_collector.get_metrics("system")
            agent_metrics = await self.metrics_collector.get_metrics("agents")
            workflow_metrics = await self.metrics_collector.get_metrics("workflows")
            business_metrics = await self.metrics_collector.get_metrics("business")
            
            return {
                "timestamp": datetime.now(),
                "system": system_metrics,
                "agents": agent_metrics,
                "workflows": workflow_metrics,
                "business": business_metrics
            }
        
        except Exception as e:
            self.logger.error(f"Failed to get performance snapshot: {str(e)}")
            return {}
    
    async def _detect_performance_anomalies(self, current_metrics: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Detect performance anomalies"""
        anomalies = []
        
        try:
            # Check system metrics
            system_metrics = current_metrics.get("system", {}).get("metrics", [])
            for metric in system_metrics:
                if metric.get("component_id") == "system":
                    metrics_data = metric.get("metrics", {})
                    
                    # Check CPU usage
                    cpu_usage = metrics_data.get("cpu_usage", 0)
                    if cpu_usage > 90:
                        anomalies.append({
                            "type": "high_cpu_usage",
                            "component": "system",
                            "value": cpu_usage,
                            "threshold": 90,
                            "severity": "high"
                        })
                    
                    # Check memory usage
                    memory_usage = metrics_data.get("memory_usage", 0)
                    if memory_usage > 85:
                        anomalies.append({
                            "type": "high_memory_usage",
                            "component": "system",
                            "value": memory_usage,
                            "threshold": 85,
                            "severity": "medium"
                        })
            
            return anomalies
        
        except Exception as e:
            self.logger.error(f"Failed to detect anomalies: {str(e)}")
            return []
    
    async def _handle_performance_anomalies(self, anomalies: List[Dict[str, Any]]):
        """Handle detected performance anomalies"""
        for anomaly in anomalies:
            self.logger.warning(f"Performance anomaly detected: {anomaly}")
            
            # Implement automatic remediation if possible
            await self._attempt_automatic_remediation(anomaly)
    
    async def _attempt_automatic_remediation(self, anomaly: Dict[str, Any]):
        """Attempt automatic remediation for performance issues"""
        anomaly_type = anomaly.get("type")
        
        if anomaly_type == "high_cpu_usage":
            # Could implement CPU optimization strategies
            self.logger.info("Attempting CPU usage optimization")
        elif anomaly_type == "high_memory_usage":
            # Could implement memory cleanup strategies
            self.logger.info("Attempting memory usage optimization")
    
    async def _get_performance_metrics(self, start_time: datetime, end_time: datetime) -> Dict[str, Any]:
        """Get performance metrics for time range"""
        try:
            time_range = (start_time, end_time)
            
            system_metrics = await self.metrics_collector.get_metrics("system", time_range=time_range)
            agent_metrics = await self.metrics_collector.get_metrics("agents", time_range=time_range)
            workflow_metrics = await self.metrics_collector.get_metrics("workflows", time_range=time_range)
            business_metrics = await self.metrics_collector.get_metrics("business", time_range=time_range)
            
            return {
                "time_range": {"start": start_time, "end": end_time},
                "system": system_metrics,
                "agents": agent_metrics,
                "workflows": workflow_metrics,
                "business": business_metrics
            }
        
        except Exception as e:
            self.logger.error(f"Failed to get performance metrics: {str(e)}")
            return {}
    
    async def _analyze_performance_trends(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze performance trends"""
        trends = {
            "system_trends": {},
            "agent_trends": {},
            "workflow_trends": {},
            "business_trends": {}
        }
        
        try:
            # Analyze system trends
            system_metrics = metrics.get("system", {}).get("metrics", [])
            if system_metrics:
                cpu_values = [m.get("metrics", {}).get("cpu_usage", 0) for m in system_metrics]
                memory_values = [m.get("metrics", {}).get("memory_usage", 0) for m in system_metrics]
                
                trends["system_trends"] = {
                    "cpu_trend": self._calculate_trend(cpu_values),
                    "memory_trend": self._calculate_trend(memory_values),
                    "avg_cpu": statistics.mean(cpu_values) if cpu_values else 0,
                    "avg_memory": statistics.mean(memory_values) if memory_values else 0
                }
            
            return trends
        
        except Exception as e:
            self.logger.error(f"Failed to analyze trends: {str(e)}")
            return trends
    
    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction from values"""
        if len(values) < 2:
            return "stable"
        
        # Simple trend calculation
        first_half = values[:len(values)//2]
        second_half = values[len(values)//2:]
        
        first_avg = statistics.mean(first_half)
        second_avg = statistics.mean(second_half)
        
        if second_avg > first_avg * 1.1:
            return "increasing"
        elif second_avg < first_avg * 0.9:
            return "decreasing"
        else:
            return "stable"
    
    async def _generate_optimization_recommendations(self, trends: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate optimization recommendations based on trends"""
        recommendations = []
        
        try:
            system_trends = trends.get("system_trends", {})
            
            # CPU optimization recommendations
            if system_trends.get("cpu_trend") == "increasing":
                recommendations.append({
                    "type": "cpu_optimization",
                    "priority": "high",
                    "description": "CPU usage is trending upward. Consider optimizing agent workloads or scaling resources.",
                    "actions": [
                        "Review agent task distribution",
                        "Optimize workflow execution",
                        "Consider horizontal scaling"
                    ]
                })
            
            # Memory optimization recommendations
            if system_trends.get("memory_trend") == "increasing":
                recommendations.append({
                    "type": "memory_optimization",
                    "priority": "medium",
                    "description": "Memory usage is trending upward. Consider memory cleanup or optimization.",
                    "actions": [
                        "Review memory usage patterns",
                        "Implement memory cleanup routines",
                        "Optimize data structures"
                    ]
                })
            
            return recommendations
        
        except Exception as e:
            self.logger.error(f"Failed to generate recommendations: {str(e)}")
            return []
    
    async def _store_recommendations(self, recommendations: List[Dict[str, Any]], analysis_type: str):
        """Store optimization recommendations"""
        try:
            # Store in database for tracking
            for recommendation in recommendations:
                # This would store recommendations in database
                self.logger.info(f"Recommendation ({analysis_type}): {recommendation['description']}")
        
        except Exception as e:
            self.logger.error(f"Failed to store recommendations: {str(e)}")
    
    async def _generate_daily_report(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Generate daily performance report"""
        try:
            report = {
                "report_type": "daily",
                "generated_at": datetime.now(),
                "time_range": metrics.get("time_range"),
                "summary": {},
                "key_metrics": {},
                "issues": [],
                "recommendations": []
            }
            
            # Calculate summary statistics
            system_metrics = metrics.get("system", {}).get("metrics", [])
            if system_metrics:
                cpu_values = [m.get("metrics", {}).get("cpu_usage", 0) for m in system_metrics]
                memory_values = [m.get("metrics", {}).get("memory_usage", 0) for m in system_metrics]
                
                report["summary"] = {
                    "avg_cpu_usage": statistics.mean(cpu_values) if cpu_values else 0,
                    "max_cpu_usage": max(cpu_values) if cpu_values else 0,
                    "avg_memory_usage": statistics.mean(memory_values) if memory_values else 0,
                    "max_memory_usage": max(memory_values) if memory_values else 0
                }
            
            return report
        
        except Exception as e:
            self.logger.error(f"Failed to generate daily report: {str(e)}")
            return {}
    
    async def _generate_comprehensive_analysis(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """Generate comprehensive weekly analysis"""
        try:
            analysis = {
                "analysis_type": "weekly",
                "generated_at": datetime.now(),
                "time_range": metrics.get("time_range"),
                "performance_summary": {},
                "trend_analysis": {},
                "capacity_planning": {},
                "optimization_opportunities": [],
                "action_items": []
            }
            
            # Perform comprehensive analysis
            trends = await self._analyze_performance_trends(metrics)
            analysis["trend_analysis"] = trends
            
            # Generate optimization opportunities
            opportunities = await self._generate_optimization_recommendations(trends)
            analysis["optimization_opportunities"] = opportunities
            
            return analysis
        
        except Exception as e:
            self.logger.error(f"Failed to generate comprehensive analysis: {str(e)}")
            return {}
    
    async def _store_performance_report(self, report: Dict[str, Any], report_type: str):
        """Store performance report"""
        try:
            # Store report in database and file system
            report_id = str(uuid.uuid4())
            
            # Save to file
            report_dir = Path(f"/app/reports/{report_type}")
            report_dir.mkdir(parents=True, exist_ok=True)
            
            report_file = report_dir / f"report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(report_file, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            
            self.logger.info(f"Performance report saved: {report_file}")
        
        except Exception as e:
            self.logger.error(f"Failed to store performance report: {str(e)}")


# Database schema for monitoring
MONITORING_SCHEMA = """
CREATE TABLE IF NOT EXISTS alerts (
    alert_id VARCHAR(255) PRIMARY KEY,
    rule_id VARCHAR(255) NOT NULL,
    alert_name VARCHAR(255) NOT NULL,
    severity VARCHAR(50) NOT NULL,
    message TEXT NOT NULL,
    metric_value FLOAT,
    threshold_value FLOAT,
    triggered_at TIMESTAMP NOT NULL,
    resolved_at TIMESTAMP,
    status VARCHAR(50) DEFAULT 'active',
    metadata JSONB DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS alert_rules (
    rule_id VARCHAR(255) PRIMARY KEY,
    rule_name VARCHAR(255) NOT NULL,
    metric_name VARCHAR(255) NOT NULL,
    condition VARCHAR(50) NOT NULL,
    threshold_value FLOAT NOT NULL,
    severity VARCHAR(50) NOT NULL,
    duration_minutes INTEGER DEFAULT 5,
    notification_channels JSONB DEFAULT '[]',
    enabled BOOLEAN DEFAULT true,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS performance_reports (
    report_id VARCHAR(255) PRIMARY KEY,
    report_type VARCHAR(50) NOT NULL,
    generated_at TIMESTAMP NOT NULL,
    time_range JSONB NOT NULL,
    report_data JSONB NOT NULL,
    file_path VARCHAR(500)
);

CREATE INDEX IF NOT EXISTS idx_alerts_triggered_at ON alerts(triggered_at);
CREATE INDEX IF NOT EXISTS idx_alerts_status ON alerts(status);
CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity);
CREATE INDEX IF NOT EXISTS idx_alert_rules_enabled ON alert_rules(enabled);
CREATE INDEX IF NOT EXISTS idx_performance_reports_type ON performance_reports(report_type);
CREATE INDEX IF NOT EXISTS idx_performance_reports_generated_at ON performance_reports(generated_at);
"""


def setup_monitoring_database(db_connection):
    """Setup database schema for monitoring"""
    try:
        with db_connection.cursor() as cursor:
            cursor.execute(MONITORING_SCHEMA)
        db_connection.commit()
        print("Monitoring database schema created successfully")
    except Exception as e:
        print(f"Failed to create monitoring database schema: {str(e)}")


if __name__ == "__main__":
    # Example usage and testing
    import redis
    import psycopg2
    from elasticsearch import Elasticsearch
    
    async def main():
        # Setup connections
        redis_client = redis.Redis(host='localhost', port=6379, db=0)
        db_connection = psycopg2.connect(
            host="localhost",
            database="aiagent",
            user="aiagent",
            password="password"
        )
        elasticsearch_client = Elasticsearch([{'host': 'localhost', 'port': 9200}])
        
        # Setup database
        setup_monitoring_database(db_connection)
        
        # Initialize monitoring components
        metrics_collector = MetricsCollector(redis_client, db_connection, elasticsearch_client)
        alert_manager = AlertManager(redis_client, db_connection, metrics_collector)
        performance_analyzer = PerformanceAnalyzer(metrics_collector, alert_manager)
        
        print("Comprehensive Monitoring System initialized successfully")
        print("Ready for monitoring AI Agent Life Operating System")
    
    asyncio.run(main())

