# Complete Infrastructure Setup Guide - AI Agent Life Operating System

**Author:** Manus AI  
**Date:** July 8, 2025  
**Version:** 1.0  
**Document Type:** Practical Implementation Guide  

## Prerequisites and Environment Preparation

Before beginning the infrastructure setup, you must prepare your development environment and ensure all prerequisites are met. This section provides detailed instructions for setting up your local development machine and cloud infrastructure to support the AI Agent Life Operating System deployment.

### Local Development Environment Setup

Your local development machine serves as the command center for deploying and managing the entire AI Agent Life Operating System. The local environment requires specific tools and configurations to interact with cloud infrastructure, manage Kubernetes clusters, and deploy applications effectively.

Begin by installing Docker Desktop on your local machine, which provides the container runtime and Kubernetes development environment necessary for testing and development activities. Download Docker Desktop from the official website at https://www.docker.com/products/docker-desktop and follow the installation instructions for your operating system. After installation, enable Kubernetes in Docker Desktop settings to provide a local Kubernetes cluster for development and testing purposes.

Install kubectl, the Kubernetes command-line tool, which enables interaction with Kubernetes clusters from your local machine. The kubectl installation varies by operating system, but the most reliable method involves downloading the binary directly from the Kubernetes release page. For Linux systems, execute the following commands to install kubectl:

```bash
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
kubectl version --client
```

For macOS systems using Homebrew, install kubectl with the command `brew install kubectl`. Windows users should download the kubectl.exe binary and add it to their system PATH environment variable.

Install Helm, the Kubernetes package manager, which simplifies the deployment of complex applications and services. Helm charts provide pre-configured application templates that significantly reduce deployment complexity and ensure best practices. Install Helm using the following commands:

```bash
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
helm version
```

Configure your local Git environment for version control and collaboration. Install Git if not already present, and configure your user information:

```bash
git config --global user.name "Your Name"
git config --global user.email "your.email@example.com"
git config --global init.defaultBranch main
```

Install a code editor with Kubernetes and YAML support. Visual Studio Code with the Kubernetes extension provides excellent support for Kubernetes development, including syntax highlighting, auto-completion, and cluster management capabilities.

### Cloud Infrastructure Selection and Setup

The AI Agent Life Operating System requires robust cloud infrastructure to support the Kubernetes cluster, storage systems, and networking requirements. While the system can run on any major cloud provider, this guide focuses on cost-effective solutions that provide excellent performance and reliability.

For budget-conscious deployments, consider using cloud providers that offer competitive pricing and generous free tiers. DigitalOcean provides excellent value with their managed Kubernetes service, while Linode offers competitive pricing for virtual machines. Google Cloud Platform provides substantial free credits for new users, and AWS offers a comprehensive free tier for the first year.

Create accounts with your chosen cloud provider and configure billing alerts to monitor costs and prevent unexpected charges. Most cloud providers offer cost management tools that help track spending and optimize resource utilization.

Set up cloud provider CLI tools to enable command-line management of cloud resources. For DigitalOcean, install doctl:

```bash
wget https://github.com/digitalocean/doctl/releases/download/v1.94.0/doctl-1.94.0-linux-amd64.tar.gz
tar xf doctl-1.94.0-linux-amd64.tar.gz
sudo mv doctl /usr/local/bin
doctl auth init
```

For Google Cloud Platform, install gcloud CLI:

```bash
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
gcloud init
```

Configure authentication and default settings for your cloud provider CLI tools. This typically involves creating API tokens or service account keys and configuring default regions and projects.

### Network and Security Planning

Network architecture planning ensures secure, efficient communication between system components while providing appropriate access controls and monitoring capabilities. The network design must accommodate both internal cluster communication and external access to user interfaces and APIs.

Plan your IP address ranges and subnets to avoid conflicts with existing networks and provide room for future expansion. Reserve specific IP ranges for the Kubernetes cluster, load balancers, and any additional services. Document your network plan to ensure consistent configuration across all components.

Configure DNS settings for your domain names and subdomains. The AI Agent Life Operating System requires multiple DNS entries for different services including the main application interface, API endpoints, monitoring dashboards, and administrative interfaces. Purchase a domain name if you don't already have one, and configure DNS management through your domain registrar or a dedicated DNS service like Cloudflare.

Plan SSL certificate management using Let's Encrypt for free SSL certificates or your preferred certificate authority for commercial certificates. The system requires SSL certificates for all public-facing services to ensure secure communication and meet modern security standards.

## Kubernetes Cluster Deployment

The Kubernetes cluster forms the foundation of the AI Agent Life Operating System, providing container orchestration, service discovery, load balancing, and scaling capabilities. The cluster deployment process involves careful configuration of nodes, networking, storage, and security settings to ensure optimal performance and reliability.

### Managed Kubernetes Service Setup

Managed Kubernetes services significantly reduce operational overhead by handling cluster management, updates, and maintenance tasks automatically. This approach allows you to focus on application deployment and optimization rather than infrastructure management.

For DigitalOcean Kubernetes (DOKS), create a new cluster using the web interface or command line. The recommended configuration includes three worker nodes with 4 CPU cores and 8 GB RAM each, providing sufficient resources for the initial deployment while allowing for scaling as needed.

```bash
doctl kubernetes cluster create ai-agent-cluster \
  --region nyc1 \
  --version 1.28.2-do.0 \
  --node-pool "name=worker-pool;size=s-4vcpu-8gb;count=3;auto-scale=true;min-nodes=3;max-nodes=10"
```

Configure kubectl to connect to your new cluster:

```bash
doctl kubernetes cluster kubeconfig save ai-agent-cluster
kubectl cluster-info
kubectl get nodes
```

For Google Kubernetes Engine (GKE), create a cluster with similar specifications:

```bash
gcloud container clusters create ai-agent-cluster \
  --zone us-central1-a \
  --machine-type e2-standard-4 \
  --num-nodes 3 \
  --enable-autoscaling \
  --min-nodes 3 \
  --max-nodes 10 \
  --enable-autorepair \
  --enable-autoupgrade
```

Configure kubectl for GKE:

```bash
gcloud container clusters get-credentials ai-agent-cluster --zone us-central1-a
```

Verify cluster connectivity and basic functionality:

```bash
kubectl get nodes -o wide
kubectl get namespaces
kubectl get pods --all-namespaces
```

### Storage Configuration

Persistent storage configuration ensures that data remains available across pod restarts and node failures. The AI Agent Life Operating System requires multiple types of storage including high-performance storage for databases and standard storage for logs and backups.

Create storage classes for different performance requirements. High-performance SSD storage supports databases and applications requiring low latency, while standard storage provides cost-effective solutions for logs, backups, and less performance-sensitive data.

For DigitalOcean, create storage classes:

```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: do-block-storage-ssd
provisioner: dobs.csi.digitalocean.com
parameters:
  type: pd-ssd
allowVolumeExpansion: true
reclaimPolicy: Retain
---
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: do-block-storage-standard
provisioner: dobs.csi.digitalocean.com
parameters:
  type: pd-standard
allowVolumeExpansion: true
reclaimPolicy: Retain
```

Apply the storage class configuration:

```bash
kubectl apply -f storage-classes.yaml
kubectl get storageclass
```

Test storage functionality by creating a test persistent volume claim:

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: test-pvc
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: do-block-storage-ssd
  resources:
    requests:
      storage: 10Gi
```

```bash
kubectl apply -f test-pvc.yaml
kubectl get pvc
kubectl describe pvc test-pvc
```

### Network Configuration and Ingress Setup

Network configuration enables external access to applications and services while maintaining security and performance. The ingress controller manages HTTP and HTTPS traffic routing to appropriate services based on hostnames and paths.

Install an ingress controller to manage external traffic routing. NGINX Ingress Controller provides excellent performance and extensive configuration options:

```bash
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update
helm install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx \
  --create-namespace \
  --set controller.service.type=LoadBalancer
```

Verify ingress controller installation:

```bash
kubectl get pods -n ingress-nginx
kubectl get services -n ingress-nginx
```

Configure DNS records to point your domain names to the ingress controller's external IP address. Obtain the external IP address:

```bash
kubectl get service ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].ip}'
```

Create DNS A records for your domain and subdomains pointing to this IP address. The typical DNS configuration includes:
- `ai-agent.yourdomain.com` - Main application interface
- `api.yourdomain.com` - API endpoints
- `grafana.yourdomain.com` - Monitoring dashboard
- `airflow.yourdomain.com` - Workflow management interface

### SSL Certificate Management

SSL certificate management ensures secure communication for all public-facing services. cert-manager automates certificate provisioning and renewal using Let's Encrypt or other certificate authorities.

Install cert-manager using Helm:

```bash
helm repo add jetstack https://charts.jetstack.io
helm repo update
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.crds.yaml
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --create-namespace \
  --version v1.13.0
```

Verify cert-manager installation:

```bash
kubectl get pods -n cert-manager
kubectl get crd | grep cert-manager
```

Create a ClusterIssuer for Let's Encrypt:

```yaml
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: your.email@example.com
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
    - http01:
        ingress:
          class: nginx
```

Apply the ClusterIssuer configuration:

```bash
kubectl apply -f cluster-issuer.yaml
kubectl get clusterissuer
```

Test certificate provisioning with a simple test service:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: test-service
spec:
  selector:
    app: test-app
  ports:
    - port: 80
      targetPort: 8080
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: test-ingress
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/rewrite-target: /
spec:
  tls:
  - hosts:
    - test.yourdomain.com
    secretName: test-tls
  rules:
  - host: test.yourdomain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: test-service
            port:
              number: 80
```

## Database Infrastructure Setup

Database infrastructure provides persistent data storage for all system components including application data, configuration settings, workflow state, and monitoring metrics. The database setup involves deploying PostgreSQL for primary data storage and configuring backup and recovery procedures.

### PostgreSQL Deployment and Configuration

PostgreSQL serves as the primary database for the AI Agent Life Operating System, supporting Apache Airflow, application data, and configuration storage. The PostgreSQL deployment requires careful configuration for performance, security, and reliability.

Create a dedicated namespace for database services:

```bash
kubectl create namespace databases
```

Deploy PostgreSQL using a Helm chart that provides production-ready configuration:

```bash
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo update
```

Create a values file for PostgreSQL configuration:

```yaml
# postgresql-values.yaml
auth:
  postgresPassword: "your-secure-postgres-password"
  username: "aiagent"
  password: "your-secure-user-password"
  database: "aiagent"

primary:
  persistence:
    enabled: true
    storageClass: "do-block-storage-ssd"
    size: 100Gi
  
  resources:
    requests:
      memory: "2Gi"
      cpu: "1000m"
    limits:
      memory: "4Gi"
      cpu: "2000m"

  configuration: |
    max_connections = 200
    shared_buffers = 1GB
    effective_cache_size = 3GB
    maintenance_work_mem = 256MB
    checkpoint_completion_target = 0.9
    wal_buffers = 16MB
    default_statistics_target = 100
    random_page_cost = 1.1
    effective_io_concurrency = 200
    work_mem = 10MB
    min_wal_size = 1GB
    max_wal_size = 4GB

metrics:
  enabled: true
  serviceMonitor:
    enabled: true
```

Deploy PostgreSQL:

```bash
helm install postgresql bitnami/postgresql \
  --namespace databases \
  --values postgresql-values.yaml
```

Verify PostgreSQL deployment:

```bash
kubectl get pods -n databases
kubectl get services -n databases
kubectl logs -n databases postgresql-0
```

Test database connectivity:

```bash
kubectl run postgresql-client --rm --tty -i --restart='Never' \
  --namespace databases \
  --image docker.io/bitnami/postgresql:15 \
  --env="PGPASSWORD=your-secure-user-password" \
  --command -- psql --host postgresql.databases.svc.cluster.local -U aiagent -d aiagent -p 5432
```

### Database Security and Access Control

Database security configuration ensures that sensitive data remains protected while enabling necessary access for applications and administrators. The security configuration includes network policies, authentication settings, and encryption options.

Create network policies to restrict database access to authorized pods only:

```yaml
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: postgresql-netpol
  namespace: databases
spec:
  podSelector:
    matchLabels:
      app.kubernetes.io/name: postgresql
  policyTypes:
  - Ingress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: airflow
    - namespaceSelector:
        matchLabels:
          name: applications
    ports:
    - protocol: TCP
      port: 5432
```

Apply the network policy:

```bash
kubectl apply -f postgresql-netpol.yaml
kubectl get networkpolicy -n databases
```

Configure database users and permissions for different applications:

```sql
-- Connect to PostgreSQL as postgres user
CREATE USER airflow_user WITH PASSWORD 'secure-airflow-password';
CREATE DATABASE airflow_db OWNER airflow_user;
GRANT ALL PRIVILEGES ON DATABASE airflow_db TO airflow_user;

CREATE USER n8n_user WITH PASSWORD 'secure-n8n-password';
CREATE DATABASE n8n_db OWNER n8n_user;
GRANT ALL PRIVILEGES ON DATABASE n8n_db TO n8n_user;

CREATE USER grafana_user WITH PASSWORD 'secure-grafana-password';
CREATE DATABASE grafana_db OWNER grafana_user;
GRANT ALL PRIVILEGES ON DATABASE grafana_db TO grafana_user;
```

Create Kubernetes secrets for database credentials:

```bash
kubectl create secret generic postgresql-airflow-secret \
  --namespace airflow \
  --from-literal=username=airflow_user \
  --from-literal=password=secure-airflow-password \
  --from-literal=database=airflow_db \
  --from-literal=host=postgresql.databases.svc.cluster.local \
  --from-literal=port=5432

kubectl create secret generic postgresql-n8n-secret \
  --namespace n8n \
  --from-literal=username=n8n_user \
  --from-literal=password=secure-n8n-password \
  --from-literal=database=n8n_db \
  --from-literal=host=postgresql.databases.svc.cluster.local \
  --from-literal=port=5432
```

### Backup and Recovery Configuration

Database backup and recovery procedures ensure data protection and business continuity. The backup strategy includes automated daily backups, point-in-time recovery capabilities, and disaster recovery procedures.

Create a backup storage bucket in your cloud provider for storing database backups. For DigitalOcean Spaces:

```bash
doctl compute spaces create ai-agent-backups --region nyc3
```

Install and configure a backup solution using pg_dump and cloud storage integration. Create a backup script:

```bash
#!/bin/bash
# backup-postgresql.sh

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_NAME="postgresql_backup_${TIMESTAMP}.sql"
S3_BUCKET="ai-agent-backups"

# Export database
kubectl exec -n databases postgresql-0 -- pg_dump -U postgres -d aiagent > /tmp/${BACKUP_NAME}

# Compress backup
gzip /tmp/${BACKUP_NAME}

# Upload to cloud storage
aws s3 cp /tmp/${BACKUP_NAME}.gz s3://${S3_BUCKET}/postgresql/

# Clean up local files
rm /tmp/${BACKUP_NAME}.gz

# Retain only last 30 days of backups
aws s3 ls s3://${S3_BUCKET}/postgresql/ | while read -r line; do
  createDate=$(echo $line | awk '{print $1" "$2}')
  createDate=$(date -d"$createDate" +%s)
  olderThan=$(date -d"30 days ago" +%s)
  if [[ $createDate -lt $olderThan ]]; then
    fileName=$(echo $line | awk '{print $4}')
    if [[ $fileName != "" ]]; then
      aws s3 rm s3://${S3_BUCKET}/postgresql/$fileName
    fi
  fi
done
```

Create a Kubernetes CronJob for automated backups:

```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: postgresql-backup
  namespace: databases
spec:
  schedule: "0 2 * * *"  # Daily at 2 AM
  jobTemplate:
    spec:
      template:
        spec:
          containers:
          - name: backup
            image: postgres:15
            env:
            - name: PGPASSWORD
              valueFrom:
                secretKeyRef:
                  name: postgresql
                  key: postgres-password
            command:
            - /bin/bash
            - -c
            - |
              TIMESTAMP=$(date +%Y%m%d_%H%M%S)
              pg_dump -h postgresql.databases.svc.cluster.local -U postgres -d aiagent > /tmp/backup_${TIMESTAMP}.sql
              # Add cloud upload logic here
            volumeMounts:
            - name: backup-storage
              mountPath: /tmp
          volumes:
          - name: backup-storage
            emptyDir: {}
          restartPolicy: OnFailure
```

Apply the backup CronJob:

```bash
kubectl apply -f postgresql-backup-cronjob.yaml
kubectl get cronjob -n databases
```

## Monitoring Infrastructure Deployment

Monitoring infrastructure provides comprehensive visibility into system performance, application health, and business metrics. The monitoring stack includes Prometheus for metrics collection, Grafana for visualization, and Elasticsearch for log aggregation and analysis.

### Prometheus and Grafana Setup

Prometheus and Grafana form the core of the monitoring infrastructure, providing metrics collection, storage, alerting, and visualization capabilities. The deployment uses the kube-prometheus-stack Helm chart for a complete monitoring solution.

Create a monitoring namespace:

```bash
kubectl create namespace monitoring
```

Add the Prometheus community Helm repository:

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update
```

Create a values file for the monitoring stack:

```yaml
# monitoring-values.yaml
prometheus:
  prometheusSpec:
    retention: 30d
    storageSpec:
      volumeClaimTemplate:
        spec:
          storageClassName: do-block-storage-ssd
          accessModes: ["ReadWriteOnce"]
          resources:
            requests:
              storage: 100Gi
    
    resources:
      requests:
        memory: "2Gi"
        cpu: "1000m"
      limits:
        memory: "4Gi"
        cpu: "2000m"

grafana:
  adminPassword: "your-secure-grafana-password"
  
  persistence:
    enabled: true
    storageClassName: do-block-storage-ssd
    size: 10Gi
  
  ingress:
    enabled: true
    ingressClassName: nginx
    annotations:
      cert-manager.io/cluster-issuer: letsencrypt-prod
    hosts:
      - grafana.yourdomain.com
    tls:
      - secretName: grafana-tls
        hosts:
          - grafana.yourdomain.com

alertmanager:
  alertmanagerSpec:
    storage:
      volumeClaimTemplate:
        spec:
          storageClassName: do-block-storage-ssd
          accessModes: ["ReadWriteOnce"]
          resources:
            requests:
              storage: 10Gi

kubeStateMetrics:
  enabled: true

nodeExporter:
  enabled: true

prometheusOperator:
  enabled: true
```

Deploy the monitoring stack:

```bash
helm install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --values monitoring-values.yaml
```

Verify the monitoring deployment:

```bash
kubectl get pods -n monitoring
kubectl get services -n monitoring
kubectl get ingress -n monitoring
```

Access Grafana using the configured domain name and admin credentials. The default dashboards provide comprehensive Kubernetes cluster monitoring including node performance, pod resource usage, and application metrics.

### Elasticsearch and Kibana Deployment

Elasticsearch and Kibana provide log aggregation, search, and analysis capabilities for the AI Agent Life Operating System. The ELK stack enables centralized logging, troubleshooting, and operational insights across all system components.

Add the Elastic Helm repository:

```bash
helm repo add elastic https://helm.elastic.co
helm repo update
```

Create a values file for Elasticsearch:

```yaml
# elasticsearch-values.yaml
replicas: 3
minimumMasterNodes: 2

esConfig:
  elasticsearch.yml: |
    cluster.name: "ai-agent-logs"
    network.host: 0.0.0.0
    discovery.seed_hosts: "elasticsearch-master-headless"
    cluster.initial_master_nodes: "elasticsearch-master-0,elasticsearch-master-1,elasticsearch-master-2"

volumeClaimTemplate:
  accessModes: [ "ReadWriteOnce" ]
  storageClassName: do-block-storage-ssd
  resources:
    requests:
      storage: 100Gi

resources:
  requests:
    cpu: "1000m"
    memory: "2Gi"
  limits:
    cpu: "2000m"
    memory: "4Gi"
```

Deploy Elasticsearch:

```bash
helm install elasticsearch elastic/elasticsearch \
  --namespace monitoring \
  --values elasticsearch-values.yaml
```

Create a values file for Kibana:

```yaml
# kibana-values.yaml
elasticsearchHosts: "http://elasticsearch-master:9200"

ingress:
  enabled: true
  className: nginx
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
  hosts:
    - host: kibana.yourdomain.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: kibana-tls
      hosts:
        - kibana.yourdomain.com

resources:
  requests:
    cpu: "500m"
    memory: "1Gi"
  limits:
    cpu: "1000m"
    memory: "2Gi"
```

Deploy Kibana:

```bash
helm install kibana elastic/kibana \
  --namespace monitoring \
  --values kibana-values.yaml
```

Verify the ELK stack deployment:

```bash
kubectl get pods -n monitoring | grep elastic
kubectl get pods -n monitoring | grep kibana
kubectl get ingress -n monitoring
```

### Log Collection Configuration

Log collection configuration ensures that logs from all system components are centralized in Elasticsearch for analysis and troubleshooting. Fluent Bit provides efficient log collection and forwarding capabilities.

Add the Fluent Bit Helm repository:

```bash
helm repo add fluent https://fluent.github.io/helm-charts
helm repo update
```

Create a values file for Fluent Bit:

```yaml
# fluent-bit-values.yaml
config:
  service: |
    [SERVICE]
        Daemon Off
        Flush 1
        Log_Level info
        Parsers_File parsers.conf
        Parsers_File custom_parsers.conf
        HTTP_Server On
        HTTP_Listen 0.0.0.0
        HTTP_Port 2020
        Health_Check On

  inputs: |
    [INPUT]
        Name tail
        Path /var/log/containers/*.log
        multiline.parser docker, cri
        Tag kube.*
        Mem_Buf_Limit 50MB
        Skip_Long_Lines On

  filters: |
    [FILTER]
        Name kubernetes
        Match kube.*
        Merge_Log On
        Keep_Log Off
        K8S-Logging.Parser On
        K8S-Logging.Exclude On

  outputs: |
    [OUTPUT]
        Name es
        Match kube.*
        Host elasticsearch-master.monitoring.svc.cluster.local
        Port 9200
        Logstash_Format On
        Logstash_Prefix kubernetes
        Retry_Limit False

tolerations:
  - key: node-role.kubernetes.io/master
    operator: Exists
    effect: NoSchedule
  - operator: "Exists"
    effect: "NoExecute"
  - operator: "Exists"
    effect: "NoSchedule"
```

Deploy Fluent Bit:

```bash
helm install fluent-bit fluent/fluent-bit \
  --namespace monitoring \
  --values fluent-bit-values.yaml
```

Verify log collection:

```bash
kubectl get pods -n monitoring | grep fluent-bit
kubectl logs -n monitoring -l app.kubernetes.io/name=fluent-bit
```

Access Kibana and configure index patterns to view collected logs. Create index patterns for `kubernetes-*` to view application logs and system events.

This completes the foundational infrastructure setup for the AI Agent Life Operating System. The next phase involves deploying the core application components including Apache Airflow, WSO2 API Manager, and n8n workflow automation platform.

