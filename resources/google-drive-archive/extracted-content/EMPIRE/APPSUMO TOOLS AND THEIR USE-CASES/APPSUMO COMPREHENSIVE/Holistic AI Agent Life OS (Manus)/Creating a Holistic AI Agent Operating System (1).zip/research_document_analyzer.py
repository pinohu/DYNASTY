#!/usr/bin/env python3
"""
AI Agent Life Operating System - Research Document Analyzer
Processes all research documents to extract tool capabilities, integrations, and business opportunities
"""

import os
import json
import re
from pathlib import Path
from collections import defaultdict

class ResearchDocumentAnalyzer:
    def __init__(self):
        self.upload_dir = "/home/ubuntu/upload"
        self.output_dir = "/home/ubuntu/ai_agent_system/analysis"
        self.tool_data = {}
        self.integration_matrix = defaultdict(list)
        self.business_opportunities = defaultdict(list)
        
    def find_all_research_files(self):
        """Find all markdown research files across all directories"""
        research_files = []
        
        for root, dirs, files in os.walk(self.upload_dir):
            for file in files:
                if file.endswith('.md') and 'research' in file.lower():
                    research_files.append(os.path.join(root, file))
        
        print(f"Found {len(research_files)} research files")
        return research_files
    
    def extract_tool_name_from_filename(self, filepath):
        """Extract tool name from research file name"""
        filename = os.path.basename(filepath)
        
        # Remove common suffixes
        tool_name = filename.replace('_research.md', '').replace(' Research Report.md', '')
        tool_name = tool_name.replace('research.md', '').replace('.md', '')
        
        # Clean up the name
        tool_name = tool_name.replace('_', ' ').replace('-', ' ')
        tool_name = ' '.join(word.capitalize() for word in tool_name.split())
        
        return tool_name
    
    def analyze_document(self, filepath):
        """Analyze a single research document"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            tool_name = self.extract_tool_name_from_filename(filepath)
            
            # Extract key information using regex patterns
            analysis = {
                'tool_name': tool_name,
                'filepath': filepath,
                'capabilities': self.extract_capabilities(content),
                'integrations': self.extract_integrations(content),
                'pricing': self.extract_pricing(content),
                'use_cases': self.extract_use_cases(content),
                'apis': self.extract_apis(content),
                'automation_potential': self.assess_automation_potential(content),
                'business_opportunities': self.extract_business_opportunities(content),
                'limitations': self.extract_limitations(content)
            }
            
            return analysis
            
        except Exception as e:
            print(f"Error analyzing {filepath}: {str(e)}")
            return None
    
    def extract_capabilities(self, content):
        """Extract tool capabilities from content"""
        capabilities = []
        
        # Look for capability sections
        capability_patterns = [
            r'(?i)capabilities?[:\s]*([^\n]+)',
            r'(?i)features?[:\s]*([^\n]+)',
            r'(?i)what.*does[:\s]*([^\n]+)',
            r'(?i)functionality[:\s]*([^\n]+)'
        ]
        
        for pattern in capability_patterns:
            matches = re.findall(pattern, content)
            capabilities.extend(matches)
        
        # Look for bullet points and lists
        bullet_patterns = [
            r'[•\-\*]\s*([^\n]+)',
            r'\d+\.\s*([^\n]+)'
        ]
        
        for pattern in bullet_patterns:
            matches = re.findall(pattern, content)
            capabilities.extend([match for match in matches if len(match) > 10])
        
        return list(set(capabilities))[:10]  # Limit to top 10 unique capabilities
    
    def extract_integrations(self, content):
        """Extract integration information"""
        integrations = []
        
        integration_patterns = [
            r'(?i)integrat(?:es?|ion).*?with\s+([A-Za-z0-9\s,]+)',
            r'(?i)connect(?:s|ion).*?to\s+([A-Za-z0-9\s,]+)',
            r'(?i)works?\s+with\s+([A-Za-z0-9\s,]+)',
            r'(?i)compatible\s+with\s+([A-Za-z0-9\s,]+)'
        ]
        
        for pattern in integration_patterns:
            matches = re.findall(pattern, content)
            for match in matches:
                # Split on common separators
                tools = re.split(r'[,;]', match)
                integrations.extend([tool.strip() for tool in tools if tool.strip()])
        
        return list(set(integrations))[:15]  # Limit to top 15 integrations
    
    def extract_pricing(self, content):
        """Extract pricing information"""
        pricing_patterns = [
            r'\$(\d+(?:\.\d{2})?)',
            r'(?i)price[:\s]*\$?(\d+)',
            r'(?i)cost[:\s]*\$?(\d+)',
            r'(?i)(\d+)\s*credits?',
            r'(?i)tier\s*(\d+)'
        ]
        
        pricing_info = []
        for pattern in pricing_patterns:
            matches = re.findall(pattern, content)
            pricing_info.extend(matches)
        
        return pricing_info[:5]  # Limit to top 5 pricing points
    
    def extract_use_cases(self, content):
        """Extract use cases and applications"""
        use_cases = []
        
        use_case_patterns = [
            r'(?i)use\s+case[:\s]*([^\n]+)',
            r'(?i)application[:\s]*([^\n]+)',
            r'(?i)perfect\s+for[:\s]*([^\n]+)',
            r'(?i)ideal\s+for[:\s]*([^\n]+)',
            r'(?i)best\s+for[:\s]*([^\n]+)'
        ]
        
        for pattern in use_case_patterns:
            matches = re.findall(pattern, content)
            use_cases.extend(matches)
        
        return list(set(use_cases))[:8]  # Limit to top 8 use cases
    
    def extract_apis(self, content):
        """Extract API and webhook information"""
        api_info = []
        
        api_patterns = [
            r'(?i)api[:\s]*([^\n]+)',
            r'(?i)webhook[:\s]*([^\n]+)',
            r'(?i)rest\s+api',
            r'(?i)graphql',
            r'(?i)endpoint[:\s]*([^\n]+)'
        ]
        
        for pattern in api_patterns:
            matches = re.findall(pattern, content)
            if isinstance(matches, list):
                api_info.extend(matches)
            else:
                api_info.append(matches)
        
        return list(set(api_info))[:5]  # Limit to top 5 API features
    
    def assess_automation_potential(self, content):
        """Assess automation potential on a scale of 1-10"""
        automation_keywords = [
            'automat', 'workflow', 'trigger', 'webhook', 'api', 'integration',
            'batch', 'bulk', 'schedule', 'recurring', 'pipeline', 'process'
        ]
        
        content_lower = content.lower()
        score = 0
        
        for keyword in automation_keywords:
            score += content_lower.count(keyword)
        
        # Normalize to 1-10 scale
        if score >= 20:
            return 10
        elif score >= 15:
            return 9
        elif score >= 10:
            return 8
        elif score >= 7:
            return 7
        elif score >= 5:
            return 6
        elif score >= 3:
            return 5
        elif score >= 2:
            return 4
        elif score >= 1:
            return 3
        else:
            return 2
    
    def extract_business_opportunities(self, content):
        """Extract business and revenue opportunities"""
        opportunities = []
        
        business_patterns = [
            r'(?i)revenue[:\s]*([^\n]+)',
            r'(?i)monetiz[:\s]*([^\n]+)',
            r'(?i)business\s+model[:\s]*([^\n]+)',
            r'(?i)profit[:\s]*([^\n]+)',
            r'(?i)opportunity[:\s]*([^\n]+)',
            r'(?i)market[:\s]*([^\n]+)'
        ]
        
        for pattern in business_patterns:
            matches = re.findall(pattern, content)
            opportunities.extend(matches)
        
        return list(set(opportunities))[:5]  # Limit to top 5 opportunities
    
    def extract_limitations(self, content):
        """Extract limitations and constraints"""
        limitations = []
        
        limitation_patterns = [
            r'(?i)limitation[:\s]*([^\n]+)',
            r'(?i)constraint[:\s]*([^\n]+)',
            r'(?i)cannot[:\s]*([^\n]+)',
            r'(?i)does\s+not[:\s]*([^\n]+)',
            r'(?i)limitation[:\s]*([^\n]+)'
        ]
        
        for pattern in limitation_patterns:
            matches = re.findall(pattern, content)
            limitations.extend(matches)
        
        return list(set(limitations))[:5]  # Limit to top 5 limitations
    
    def analyze_all_documents(self):
        """Analyze all research documents"""
        research_files = self.find_all_research_files()
        
        print("Analyzing research documents...")
        
        for i, filepath in enumerate(research_files):
            if i % 50 == 0:
                print(f"Processed {i}/{len(research_files)} files...")
            
            analysis = self.analyze_document(filepath)
            if analysis:
                tool_name = analysis['tool_name']
                self.tool_data[tool_name] = analysis
                
                # Build integration matrix
                for integration in analysis['integrations']:
                    self.integration_matrix[tool_name].append(integration)
                
                # Collect business opportunities
                for opportunity in analysis['business_opportunities']:
                    self.business_opportunities[tool_name].append(opportunity)
        
        print(f"Analysis complete! Processed {len(self.tool_data)} tools.")
        
        # Save comprehensive analysis
        self.save_analysis()
    
    def save_analysis(self):
        """Save the complete analysis to files"""
        
        # Save raw data as JSON
        with open(f"{self.output_dir}/comprehensive_tool_analysis.json", 'w') as f:
            json.dump({
                'tool_data': self.tool_data,
                'integration_matrix': dict(self.integration_matrix),
                'business_opportunities': dict(self.business_opportunities),
                'summary': {
                    'total_tools_analyzed': len(self.tool_data),
                    'total_integrations': sum(len(integrations) for integrations in self.integration_matrix.values()),
                    'total_opportunities': sum(len(opportunities) for opportunities in self.business_opportunities.values())
                }
            }, f, indent=2)
        
        # Create markdown summary
        with open(f"{self.output_dir}/comprehensive_tool_analysis.md", 'w') as f:
            f.write("# Comprehensive Tool Analysis Report\n\n")
            f.write(f"**Analysis Date:** July 8, 2025\n")
            f.write(f"**Tools Analyzed:** {len(self.tool_data)}\n")
            f.write(f"**Total Integrations Identified:** {sum(len(integrations) for integrations in self.integration_matrix.values())}\n")
            f.write(f"**Business Opportunities:** {sum(len(opportunities) for opportunities in self.business_opportunities.values())}\n\n")
            
            # Top automation potential tools
            automation_scores = [(name, data['automation_potential']) for name, data in self.tool_data.items()]
            automation_scores.sort(key=lambda x: x[1], reverse=True)
            
            f.write("## Top 20 Tools by Automation Potential\n\n")
            for i, (tool, score) in enumerate(automation_scores[:20], 1):
                f.write(f"{i}. **{tool}** (Score: {score}/10)\n")
            
            f.write("\n## Integration Network Analysis\n\n")
            integration_counts = [(tool, len(integrations)) for tool, integrations in self.integration_matrix.items()]
            integration_counts.sort(key=lambda x: x[1], reverse=True)
            
            f.write("### Top 15 Most Connected Tools\n\n")
            for i, (tool, count) in enumerate(integration_counts[:15], 1):
                f.write(f"{i}. **{tool}** ({count} integrations)\n")
            
            f.write("\n## Business Opportunity Matrix\n\n")
            opportunity_counts = [(tool, len(opportunities)) for tool, opportunities in self.business_opportunities.items()]
            opportunity_counts.sort(key=lambda x: x[1], reverse=True)
            
            f.write("### Top 15 Tools with Business Opportunities\n\n")
            for i, (tool, count) in enumerate(opportunity_counts[:15], 1):
                f.write(f"{i}. **{tool}** ({count} opportunities identified)\n")

if __name__ == "__main__":
    analyzer = ResearchDocumentAnalyzer()
    analyzer.analyze_all_documents()
    print("\nAnalysis files created:")
    print("- comprehensive_tool_analysis.json")
    print("- comprehensive_tool_analysis.md")

