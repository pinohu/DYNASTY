#!/usr/bin/env python3
"""
AI Agent Life Operating System - Tool Integration Framework

This comprehensive framework provides the foundation for integrating all 209 AppSumo tools
into the AI Agent Life Operating System. The framework includes base classes, authentication
handlers, API clients, and integration patterns that ensure consistent, reliable, and
maintainable tool integrations.

Author: Manus AI
Date: July 8, 2025
Version: 1.0
"""

import asyncio
import json
import logging
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional, Union, Callable
from urllib.parse import urljoin, urlparse
import hashlib
import hmac
import base64
import uuid

import aiohttp
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
import jwt
from cryptography.fernet import Fernet
import redis
import psycopg2
from psycopg2.extras import RealDictCursor
import yaml


class AuthenticationType(Enum):
    """Supported authentication types for tool integrations"""
    API_KEY = "api_key"
    OAUTH2 = "oauth2"
    BASIC_AUTH = "basic_auth"
    BEARER_TOKEN = "bearer_token"
    CUSTOM = "custom"
    WEBHOOK_SIGNATURE = "webhook_signature"


class IntegrationStatus(Enum):
    """Integration status tracking"""
    ACTIVE = "active"
    INACTIVE = "inactive"
    ERROR = "error"
    RATE_LIMITED = "rate_limited"
    MAINTENANCE = "maintenance"


@dataclass
class ToolConfiguration:
    """Configuration data for individual tool integrations"""
    tool_id: str
    tool_name: str
    base_url: str
    auth_type: AuthenticationType
    auth_config: Dict[str, Any]
    rate_limit: Dict[str, int] = field(default_factory=lambda: {"requests_per_minute": 60})
    timeout: int = 30
    retry_config: Dict[str, int] = field(default_factory=lambda: {"max_retries": 3, "backoff_factor": 1})
    webhook_config: Optional[Dict[str, Any]] = None
    custom_headers: Dict[str, str] = field(default_factory=dict)
    api_version: str = "v1"
    enabled: bool = True


@dataclass
class IntegrationMetrics:
    """Metrics tracking for tool integrations"""
    tool_id: str
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    average_response_time: float = 0.0
    last_request_time: Optional[datetime] = None
    last_error: Optional[str] = None
    rate_limit_hits: int = 0
    status: IntegrationStatus = IntegrationStatus.ACTIVE


class BaseAuthenticator(ABC):
    """Base class for authentication handlers"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(f"{self.__class__.__name__}")
    
    @abstractmethod
    async def authenticate(self) -> Dict[str, str]:
        """Return authentication headers for API requests"""
        pass
    
    @abstractmethod
    async def refresh_token(self) -> bool:
        """Refresh authentication token if applicable"""
        pass
    
    @abstractmethod
    def is_token_valid(self) -> bool:
        """Check if current token is valid"""
        pass


class APIKeyAuthenticator(BaseAuthenticator):
    """API Key authentication handler"""
    
    async def authenticate(self) -> Dict[str, str]:
        api_key = self.config.get("api_key")
        header_name = self.config.get("header_name", "X-API-Key")
        
        if not api_key:
            raise ValueError("API key not provided in configuration")
        
        return {header_name: api_key}
    
    async def refresh_token(self) -> bool:
        # API keys don't typically need refreshing
        return True
    
    def is_token_valid(self) -> bool:
        return bool(self.config.get("api_key"))


class OAuth2Authenticator(BaseAuthenticator):
    """OAuth2 authentication handler"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.access_token = None
        self.refresh_token = None
        self.token_expires_at = None
    
    async def authenticate(self) -> Dict[str, str]:
        if not self.is_token_valid():
            await self.refresh_token()
        
        if not self.access_token:
            raise ValueError("Failed to obtain valid access token")
        
        return {"Authorization": f"Bearer {self.access_token}"}
    
    async def refresh_token(self) -> bool:
        """Refresh OAuth2 access token"""
        try:
            token_url = self.config.get("token_url")
            client_id = self.config.get("client_id")
            client_secret = self.config.get("client_secret")
            
            if self.refresh_token:
                # Use refresh token
                data = {
                    "grant_type": "refresh_token",
                    "refresh_token": self.refresh_token,
                    "client_id": client_id,
                    "client_secret": client_secret
                }
            else:
                # Use client credentials
                data = {
                    "grant_type": "client_credentials",
                    "client_id": client_id,
                    "client_secret": client_secret
                }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(token_url, data=data) as response:
                    if response.status == 200:
                        token_data = await response.json()
                        self.access_token = token_data.get("access_token")
                        self.refresh_token = token_data.get("refresh_token", self.refresh_token)
                        expires_in = token_data.get("expires_in", 3600)
                        self.token_expires_at = datetime.now() + timedelta(seconds=expires_in - 60)
                        return True
                    else:
                        self.logger.error(f"Token refresh failed: {response.status}")
                        return False
        
        except Exception as e:
            self.logger.error(f"Token refresh error: {str(e)}")
            return False
    
    def is_token_valid(self) -> bool:
        if not self.access_token or not self.token_expires_at:
            return False
        return datetime.now() < self.token_expires_at


class BasicAuthAuthenticator(BaseAuthenticator):
    """Basic authentication handler"""
    
    async def authenticate(self) -> Dict[str, str]:
        username = self.config.get("username")
        password = self.config.get("password")
        
        if not username or not password:
            raise ValueError("Username and password required for basic auth")
        
        credentials = base64.b64encode(f"{username}:{password}".encode()).decode()
        return {"Authorization": f"Basic {credentials}"}
    
    async def refresh_token(self) -> bool:
        return True
    
    def is_token_valid(self) -> bool:
        return bool(self.config.get("username") and self.config.get("password"))


class BearerTokenAuthenticator(BaseAuthenticator):
    """Bearer token authentication handler"""
    
    async def authenticate(self) -> Dict[str, str]:
        token = self.config.get("token")
        if not token:
            raise ValueError("Bearer token not provided")
        
        return {"Authorization": f"Bearer {token}"}
    
    async def refresh_token(self) -> bool:
        return True
    
    def is_token_valid(self) -> bool:
        return bool(self.config.get("token"))


class AuthenticatorFactory:
    """Factory for creating authentication handlers"""
    
    _authenticators = {
        AuthenticationType.API_KEY: APIKeyAuthenticator,
        AuthenticationType.OAUTH2: OAuth2Authenticator,
        AuthenticationType.BASIC_AUTH: BasicAuthAuthenticator,
        AuthenticationType.BEARER_TOKEN: BearerTokenAuthenticator,
    }
    
    @classmethod
    def create_authenticator(cls, auth_type: AuthenticationType, config: Dict[str, Any]) -> BaseAuthenticator:
        authenticator_class = cls._authenticators.get(auth_type)
        if not authenticator_class:
            raise ValueError(f"Unsupported authentication type: {auth_type}")
        
        return authenticator_class(config)


class RateLimiter:
    """Rate limiting implementation for API calls"""
    
    def __init__(self, redis_client: redis.Redis, tool_id: str, requests_per_minute: int = 60):
        self.redis_client = redis_client
        self.tool_id = tool_id
        self.requests_per_minute = requests_per_minute
        self.window_size = 60  # 1 minute window
    
    async def can_make_request(self) -> bool:
        """Check if request can be made within rate limits"""
        current_time = int(time.time())
        window_start = current_time - self.window_size
        
        # Clean old entries
        self.redis_client.zremrangebyscore(
            f"rate_limit:{self.tool_id}", 
            0, 
            window_start
        )
        
        # Count current requests in window
        current_requests = self.redis_client.zcard(f"rate_limit:{self.tool_id}")
        
        if current_requests >= self.requests_per_minute:
            return False
        
        # Add current request
        self.redis_client.zadd(
            f"rate_limit:{self.tool_id}", 
            {str(uuid.uuid4()): current_time}
        )
        self.redis_client.expire(f"rate_limit:{self.tool_id}", self.window_size * 2)
        
        return True
    
    async def wait_for_rate_limit(self) -> None:
        """Wait until rate limit allows next request"""
        while not await self.can_make_request():
            await asyncio.sleep(1)


class WebhookValidator:
    """Webhook signature validation"""
    
    def __init__(self, secret: str, algorithm: str = "sha256"):
        self.secret = secret.encode()
        self.algorithm = algorithm
    
    def validate_signature(self, payload: bytes, signature: str) -> bool:
        """Validate webhook signature"""
        expected_signature = hmac.new(
            self.secret,
            payload,
            getattr(hashlib, self.algorithm)
        ).hexdigest()
        
        # Remove algorithm prefix if present (e.g., "sha256=")
        if "=" in signature:
            signature = signature.split("=", 1)[1]
        
        return hmac.compare_digest(expected_signature, signature)


class BaseToolIntegration(ABC):
    """Base class for all tool integrations"""
    
    def __init__(self, config: ToolConfiguration, redis_client: redis.Redis, db_connection):
        self.config = config
        self.redis_client = redis_client
        self.db_connection = db_connection
        self.logger = logging.getLogger(f"Integration.{config.tool_name}")
        
        # Initialize authenticator
        self.authenticator = AuthenticatorFactory.create_authenticator(
            config.auth_type, 
            config.auth_config
        )
        
        # Initialize rate limiter
        self.rate_limiter = RateLimiter(
            redis_client, 
            config.tool_id, 
            config.rate_limit.get("requests_per_minute", 60)
        )
        
        # Initialize metrics
        self.metrics = self._load_metrics()
        
        # Setup HTTP session
        self.session = self._create_http_session()
    
    def _create_http_session(self) -> requests.Session:
        """Create configured HTTP session with retries"""
        session = requests.Session()
        
        retry_strategy = Retry(
            total=self.config.retry_config.get("max_retries", 3),
            backoff_factor=self.config.retry_config.get("backoff_factor", 1),
            status_forcelist=[429, 500, 502, 503, 504],
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        return session
    
    def _load_metrics(self) -> IntegrationMetrics:
        """Load metrics from database"""
        try:
            with self.db_connection.cursor(cursor_factory=RealDictCursor) as cursor:
                cursor.execute(
                    "SELECT * FROM integration_metrics WHERE tool_id = %s",
                    (self.config.tool_id,)
                )
                result = cursor.fetchone()
                
                if result:
                    return IntegrationMetrics(
                        tool_id=result["tool_id"],
                        total_requests=result["total_requests"],
                        successful_requests=result["successful_requests"],
                        failed_requests=result["failed_requests"],
                        average_response_time=result["average_response_time"],
                        last_request_time=result["last_request_time"],
                        last_error=result["last_error"],
                        rate_limit_hits=result["rate_limit_hits"],
                        status=IntegrationStatus(result["status"])
                    )
                else:
                    return IntegrationMetrics(tool_id=self.config.tool_id)
        
        except Exception as e:
            self.logger.error(f"Failed to load metrics: {str(e)}")
            return IntegrationMetrics(tool_id=self.config.tool_id)
    
    def _save_metrics(self) -> None:
        """Save metrics to database"""
        try:
            with self.db_connection.cursor() as cursor:
                cursor.execute("""
                    INSERT INTO integration_metrics (
                        tool_id, total_requests, successful_requests, failed_requests,
                        average_response_time, last_request_time, last_error,
                        rate_limit_hits, status
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (tool_id) DO UPDATE SET
                        total_requests = EXCLUDED.total_requests,
                        successful_requests = EXCLUDED.successful_requests,
                        failed_requests = EXCLUDED.failed_requests,
                        average_response_time = EXCLUDED.average_response_time,
                        last_request_time = EXCLUDED.last_request_time,
                        last_error = EXCLUDED.last_error,
                        rate_limit_hits = EXCLUDED.rate_limit_hits,
                        status = EXCLUDED.status
                """, (
                    self.metrics.tool_id,
                    self.metrics.total_requests,
                    self.metrics.successful_requests,
                    self.metrics.failed_requests,
                    self.metrics.average_response_time,
                    self.metrics.last_request_time,
                    self.metrics.last_error,
                    self.metrics.rate_limit_hits,
                    self.metrics.status.value
                ))
            self.db_connection.commit()
        
        except Exception as e:
            self.logger.error(f"Failed to save metrics: {str(e)}")
    
    async def make_request(
        self, 
        method: str, 
        endpoint: str, 
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:
        """Make authenticated API request with rate limiting and error handling"""
        
        # Check rate limits
        if not await self.rate_limiter.can_make_request():
            self.metrics.rate_limit_hits += 1
            await self.rate_limiter.wait_for_rate_limit()
        
        # Prepare request
        url = urljoin(self.config.base_url, endpoint)
        auth_headers = await self.authenticator.authenticate()
        
        request_headers = {**self.config.custom_headers, **auth_headers}
        if headers:
            request_headers.update(headers)
        
        start_time = time.time()
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                json=data,
                params=params,
                headers=request_headers,
                timeout=self.config.timeout
            )
            
            response_time = time.time() - start_time
            self._update_metrics(response_time, response.status_code < 400)
            
            if response.status_code == 401:
                # Try to refresh token and retry
                if await self.authenticator.refresh_token():
                    auth_headers = await self.authenticator.authenticate()
                    request_headers.update(auth_headers)
                    
                    response = self.session.request(
                        method=method,
                        url=url,
                        json=data,
                        params=params,
                        headers=request_headers,
                        timeout=self.config.timeout
                    )
            
            response.raise_for_status()
            
            try:
                return response.json()
            except ValueError:
                return {"response": response.text, "status_code": response.status_code}
        
        except Exception as e:
            response_time = time.time() - start_time
            self._update_metrics(response_time, False, str(e))
            self.logger.error(f"Request failed for {self.config.tool_name}: {str(e)}")
            raise
    
    def _update_metrics(self, response_time: float, success: bool, error: Optional[str] = None):
        """Update integration metrics"""
        self.metrics.total_requests += 1
        self.metrics.last_request_time = datetime.now()
        
        if success:
            self.metrics.successful_requests += 1
        else:
            self.metrics.failed_requests += 1
            self.metrics.last_error = error
        
        # Update average response time
        total_successful = self.metrics.successful_requests
        if total_successful > 0:
            self.metrics.average_response_time = (
                (self.metrics.average_response_time * (total_successful - 1) + response_time) 
                / total_successful
            )
        
        # Save metrics periodically
        if self.metrics.total_requests % 10 == 0:
            self._save_metrics()
    
    @abstractmethod
    async def test_connection(self) -> bool:
        """Test the integration connection"""
        pass
    
    @abstractmethod
    async def get_data(self, **kwargs) -> Dict[str, Any]:
        """Retrieve data from the tool"""
        pass
    
    @abstractmethod
    async def send_data(self, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
        """Send data to the tool"""
        pass
    
    async def handle_webhook(self, payload: Dict[str, Any], headers: Dict[str, str]) -> Dict[str, Any]:
        """Handle incoming webhook from the tool"""
        if self.config.webhook_config:
            validator = WebhookValidator(self.config.webhook_config.get("secret", ""))
            signature = headers.get(self.config.webhook_config.get("signature_header", "X-Signature"))
            
            if signature and not validator.validate_signature(json.dumps(payload).encode(), signature):
                raise ValueError("Invalid webhook signature")
        
        return await self.process_webhook(payload)
    
    async def process_webhook(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Process webhook payload - override in subclasses"""
        return {"status": "received", "payload": payload}


class IntegrationManager:
    """Manager for all tool integrations"""
    
    def __init__(self, redis_client: redis.Redis, db_connection):
        self.redis_client = redis_client
        self.db_connection = db_connection
        self.integrations: Dict[str, BaseToolIntegration] = {}
        self.logger = logging.getLogger("IntegrationManager")
    
    def register_integration(self, integration: BaseToolIntegration):
        """Register a tool integration"""
        self.integrations[integration.config.tool_id] = integration
        self.logger.info(f"Registered integration for {integration.config.tool_name}")
    
    def get_integration(self, tool_id: str) -> Optional[BaseToolIntegration]:
        """Get integration by tool ID"""
        return self.integrations.get(tool_id)
    
    async def test_all_connections(self) -> Dict[str, bool]:
        """Test all integration connections"""
        results = {}
        for tool_id, integration in self.integrations.items():
            try:
                results[tool_id] = await integration.test_connection()
            except Exception as e:
                self.logger.error(f"Connection test failed for {tool_id}: {str(e)}")
                results[tool_id] = False
        
        return results
    
    async def get_integration_metrics(self) -> Dict[str, IntegrationMetrics]:
        """Get metrics for all integrations"""
        return {tool_id: integration.metrics for tool_id, integration in self.integrations.items()}
    
    async def refresh_all_tokens(self) -> Dict[str, bool]:
        """Refresh authentication tokens for all integrations"""
        results = {}
        for tool_id, integration in self.integrations.items():
            try:
                results[tool_id] = await integration.authenticator.refresh_token()
            except Exception as e:
                self.logger.error(f"Token refresh failed for {tool_id}: {str(e)}")
                results[tool_id] = False
        
        return results


# Database schema for integration metrics
INTEGRATION_METRICS_SCHEMA = """
CREATE TABLE IF NOT EXISTS integration_metrics (
    tool_id VARCHAR(255) PRIMARY KEY,
    total_requests INTEGER DEFAULT 0,
    successful_requests INTEGER DEFAULT 0,
    failed_requests INTEGER DEFAULT 0,
    average_response_time FLOAT DEFAULT 0.0,
    last_request_time TIMESTAMP,
    last_error TEXT,
    rate_limit_hits INTEGER DEFAULT 0,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_integration_metrics_status ON integration_metrics(status);
CREATE INDEX IF NOT EXISTS idx_integration_metrics_updated ON integration_metrics(updated_at);
"""


def setup_database(db_connection):
    """Setup database schema for integration metrics"""
    try:
        with db_connection.cursor() as cursor:
            cursor.execute(INTEGRATION_METRICS_SCHEMA)
        db_connection.commit()
        print("Database schema created successfully")
    except Exception as e:
        print(f"Failed to create database schema: {str(e)}")


if __name__ == "__main__":
    # Example usage and testing
    import asyncio
    
    async def main():
        # Example configuration
        config = ToolConfiguration(
            tool_id="example_tool",
            tool_name="Example Tool",
            base_url="https://api.example.com/",
            auth_type=AuthenticationType.API_KEY,
            auth_config={"api_key": "your-api-key", "header_name": "X-API-Key"}
        )
        
        # This would be implemented for each specific tool
        class ExampleIntegration(BaseToolIntegration):
            async def test_connection(self) -> bool:
                try:
                    response = await self.make_request("GET", "health")
                    return response.get("status") == "ok"
                except:
                    return False
            
            async def get_data(self, **kwargs) -> Dict[str, Any]:
                return await self.make_request("GET", "data", params=kwargs)
            
            async def send_data(self, data: Dict[str, Any], **kwargs) -> Dict[str, Any]:
                return await self.make_request("POST", "data", data=data)
        
        print("Tool Integration Framework loaded successfully")
        print("Ready for specific tool implementations")
    
    asyncio.run(main())

