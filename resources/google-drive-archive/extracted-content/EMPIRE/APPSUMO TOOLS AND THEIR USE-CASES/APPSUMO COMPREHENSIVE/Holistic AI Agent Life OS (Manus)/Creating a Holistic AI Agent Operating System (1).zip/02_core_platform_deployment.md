# Core Platform Deployment Guide - AI Agent Life Operating System

**Author:** Manus AI  
**Date:** July 8, 2025  
**Version:** 1.0  
**Document Type:** Core Platform Implementation Guide  

## Apache Airflow Deployment and Configuration

Apache Airflow serves as the primary workflow orchestration platform for the AI Agent Life Operating System, managing complex multi-tool workflows and business processes. The Airflow deployment requires careful configuration for scalability, security, and integration with the broader system architecture.

### Airflow Infrastructure Setup

The Airflow deployment utilizes the official Apache Airflow Helm chart with custom configurations optimized for the AI Agent Life Operating System requirements. The deployment includes web server, scheduler, worker, and triggerer components configured for high availability and performance.

Create a dedicated namespace for Airflow:

```bash
kubectl create namespace airflow
kubectl label namespace airflow name=airflow
```

Add the Apache Airflow Helm repository:

```bash
helm repo add apache-airflow https://airflow.apache.org
helm repo update
```

Create a comprehensive values file for Airflow configuration:

```yaml
# airflow-values.yaml
images:
  airflow:
    repository: apache/airflow
    tag: 2.7.2-python3.11
    pullPolicy: IfNotPresent

executor: "CeleryExecutor"

fernetKey: "your-32-character-fernet-key-here"
webserverSecretKey: "your-secret-key-for-webserver"

config:
  core:
    dags_are_paused_at_creation: 'false'
    load_examples: 'false'
    max_active_runs_per_dag: 16
    max_active_tasks_per_dag: 16
    default_task_retries: 2
    parallelism: 32
    max_active_runs_per_dag: 16
  
  webserver:
    expose_config: 'true'
    authenticate: 'true'
    auth_backend: 'airflow.auth.backends.password_auth'
    secret_key: 'your-secret-key-for-webserver'
  
  celery:
    worker_concurrency: 16
    flower_url_prefix: '/flower'
  
  scheduler:
    catchup_by_default: 'false'
    dag_dir_list_interval: 30
    max_threads: 2
    processor_poll_interval: 1

data:
  metadataConnection:
    user: airflow_user
    pass: secure-airflow-password
    protocol: postgresql
    host: postgresql.databases.svc.cluster.local
    port: 5432
    db: airflow_db

redis:
  enabled: true
  auth:
    enabled: true
    password: "secure-redis-password"
  master:
    persistence:
      enabled: true
      storageClass: "do-block-storage-ssd"
      size: 10Gi

workers:
  replicas: 3
  resources:
    requests:
      cpu: "1000m"
      memory: "2Gi"
    limits:
      cpu: "2000m"
      memory: "4Gi"
  
  persistence:
    enabled: true
    storageClassName: "do-block-storage-ssd"
    size: 20Gi

scheduler:
  replicas: 2
  resources:
    requests:
      cpu: "1000m"
      memory: "2Gi"
    limits:
      cpu: "2000m"
      memory: "4Gi"

webserver:
  replicas: 2
  resources:
    requests:
      cpu: "500m"
      memory: "1Gi"
    limits:
      cpu: "1000m"
      memory: "2Gi"
  
  service:
    type: ClusterIP
    port: 8080

triggerer:
  enabled: true
  replicas: 1
  resources:
    requests:
      cpu: "500m"
      memory: "1Gi"
    limits:
      cpu: "1000m"
      memory: "2Gi"

flower:
  enabled: true
  resources:
    requests:
      cpu: "100m"
      memory: "256Mi"
    limits:
      cpu: "500m"
      memory: "512Mi"

ingress:
  web:
    enabled: true
    ingressClassName: nginx
    annotations:
      cert-manager.io/cluster-issuer: letsencrypt-prod
      nginx.ingress.kubernetes.io/auth-type: basic
      nginx.ingress.kubernetes.io/auth-secret: airflow-basic-auth
      nginx.ingress.kubernetes.io/auth-realm: 'Authentication Required'
    hosts:
      - name: airflow.yourdomain.com
        tls:
          enabled: true
          secretName: airflow-tls
    
  flower:
    enabled: true
    ingressClassName: nginx
    annotations:
      cert-manager.io/cluster-issuer: letsencrypt-prod
      nginx.ingress.kubernetes.io/auth-type: basic
      nginx.ingress.kubernetes.io/auth-secret: airflow-basic-auth
      nginx.ingress.kubernetes.io/auth-realm: 'Authentication Required'
    hosts:
      - name: flower.yourdomain.com
        tls:
          enabled: true
          secretName: flower-tls

dags:
  persistence:
    enabled: true
    storageClassName: "do-block-storage-ssd"
    size: 10Gi
  
  gitSync:
    enabled: true
    repo: https://github.com/yourusername/ai-agent-dags.git
    branch: main
    rev: HEAD
    depth: 1
    maxFailures: 0
    subPath: "dags"
    wait: 60
    containerName: git-sync
    uid: 65533

logs:
  persistence:
    enabled: true
    storageClassName: "do-block-storage-ssd"
    size: 50Gi

serviceMonitor:
  enabled: true
  interval: "30s"
  path: "/admin/metrics"

extraSecrets:
  airflow-connections:
    data: |
      AIRFLOW_CONN_POSTGRES_DEFAULT: postgresql://airflow_user:secure-airflow-password@postgresql.databases.svc.cluster.local:5432/airflow_db
      AIRFLOW_CONN_REDIS_DEFAULT: redis://:secure-redis-password@airflow-redis-master:6379/0
```

Create basic authentication secret for Airflow web interface:

```bash
htpasswd -c auth admin
kubectl create secret generic airflow-basic-auth --from-file=auth -n airflow
rm auth
```

Deploy Apache Airflow:

```bash
helm install airflow apache-airflow/airflow \
  --namespace airflow \
  --values airflow-values.yaml \
  --timeout 10m
```

Verify Airflow deployment:

```bash
kubectl get pods -n airflow
kubectl get services -n airflow
kubectl get ingress -n airflow
```

Wait for all pods to be ready:

```bash
kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=airflow -n airflow --timeout=600s
```

### Custom Airflow Configuration

Custom Airflow configuration includes environment-specific settings, connection configurations, and custom operators for AppSumo tool integrations. The configuration ensures optimal performance and seamless integration with the AI Agent Life Operating System.

Create custom Airflow configuration using ConfigMaps:

```yaml
# airflow-custom-config.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: airflow-custom-config
  namespace: airflow
data:
  airflow.cfg: |
    [core]
    dags_folder = /opt/airflow/dags
    hostname_callable = airflow.utils.net.getfqdn
    default_timezone = UTC
    executor = CeleryExecutor
    sql_alchemy_conn = postgresql://airflow_user:secure-airflow-password@postgresql.databases.svc.cluster.local:5432/airflow_db
    load_examples = False
    plugins_folder = /opt/airflow/plugins
    
    [webserver]
    base_url = https://airflow.yourdomain.com
    web_server_port = 8080
    web_server_host = 0.0.0.0
    secret_key = your-secret-key-for-webserver
    workers = 4
    worker_class = sync
    access_logfile = -
    error_logfile = -
    
    [celery]
    broker_url = redis://:secure-redis-password@airflow-redis-master:6379/0
    result_backend = db+postgresql://airflow_user:secure-airflow-password@postgresql.databases.svc.cluster.local:5432/airflow_db
    worker_concurrency = 16
    
    [scheduler]
    job_heartbeat_sec = 5
    scheduler_heartbeat_sec = 5
    run_duration = -1
    min_file_process_interval = 0
    dag_dir_list_interval = 300
    print_stats_interval = 30
    child_process_timeout = 60
    scheduler_zombie_task_threshold = 300
    catchup_by_default = False
    
    [logging]
    logging_level = INFO
    fab_logging_level = WARN
    log_filename_template = {{ ti.dag_id }}/{{ ti.task_id }}/{{ ts }}/{{ try_number }}.log
    log_processor_filename_template = {{ filename }}.log
    dag_processor_manager_log_location = /opt/airflow/logs/dag_processor_manager/dag_processor_manager.log
    
    [metrics]
    statsd_on = True
    statsd_host = localhost
    statsd_port = 8125
    statsd_prefix = airflow
```

Apply the custom configuration:

```bash
kubectl apply -f airflow-custom-config.yaml
```

Create Airflow connections for external services:

```bash
# Create connection to PostgreSQL
kubectl exec -n airflow airflow-scheduler-0 -- airflow connections add 'postgres_default' \
  --conn-type 'postgres' \
  --conn-host 'postgresql.databases.svc.cluster.local' \
  --conn-schema 'aiagent' \
  --conn-login 'aiagent' \
  --conn-password 'your-secure-user-password' \
  --conn-port 5432

# Create connection to Redis
kubectl exec -n airflow airflow-scheduler-0 -- airflow connections add 'redis_default' \
  --conn-type 'redis' \
  --conn-host 'airflow-redis-master' \
  --conn-password 'secure-redis-password' \
  --conn-port 6379

# Create HTTP connection for API calls
kubectl exec -n airflow airflow-scheduler-0 -- airflow connections add 'http_default' \
  --conn-type 'http' \
  --conn-host 'api.yourdomain.com' \
  --conn-schema 'https'
```

### DAG Development Environment Setup

The DAG development environment enables efficient creation, testing, and deployment of workflow definitions for the AI Agent Life Operating System. The environment includes version control integration, testing frameworks, and deployment automation.

Create a Git repository for DAG storage and version control:

```bash
mkdir ai-agent-dags
cd ai-agent-dags
git init
git remote add origin https://github.com/yourusername/ai-agent-dags.git
```

Create the basic directory structure for DAGs:

```bash
mkdir -p dags/{business_processes,personal_automation,integrations,utilities}
mkdir -p plugins/{operators,sensors,hooks}
mkdir -p tests/{unit,integration}
mkdir -p config/{connections,variables}
```

Create a sample DAG for testing the deployment:

```python
# dags/test_deployment.py
from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator

default_args = {
    'owner': 'ai-agent-system',
    'depends_on_past': False,
    'start_date': datetime(2025, 1, 1),
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    'test_deployment',
    default_args=default_args,
    description='Test DAG for deployment verification',
    schedule_interval=timedelta(hours=1),
    catchup=False,
    tags=['test', 'deployment'],
)

def test_python_function():
    """Test Python function execution"""
    import logging
    logging.info("Python function executed successfully")
    return "Success"

test_python_task = PythonOperator(
    task_id='test_python_execution',
    python_callable=test_python_function,
    dag=dag,
)

test_bash_task = BashOperator(
    task_id='test_bash_execution',
    bash_command='echo "Bash command executed successfully"',
    dag=dag,
)

test_python_task >> test_bash_task
```

Commit and push the initial DAG:

```bash
git add .
git commit -m "Initial DAG structure and test deployment"
git push origin main
```

The git-sync sidecar container will automatically pull the DAGs into the Airflow deployment.

## WSO2 API Manager Deployment

WSO2 API Manager provides comprehensive API management capabilities including security, monitoring, and governance for all tool integrations within the AI Agent Life Operating System. The deployment includes gateway, publisher, store, and analytics components.

### WSO2 API Manager Infrastructure Setup

The WSO2 API Manager deployment requires careful configuration for scalability, security, and integration with the Kubernetes environment. The deployment uses custom Kubernetes manifests optimized for the AI Agent Life Operating System requirements.

Create a dedicated namespace for WSO2 API Manager:

```bash
kubectl create namespace wso2
kubectl label namespace wso2 name=wso2
```

Create persistent volumes for WSO2 API Manager data:

```yaml
# wso2-pv.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: wso2am-shared-storage
  namespace: wso2
spec:
  accessModes:
    - ReadWriteMany
  storageClassName: do-block-storage-ssd
  resources:
    requests:
      storage: 20Gi
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: wso2am-database-storage
  namespace: wso2
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: do-block-storage-ssd
  resources:
    requests:
      storage: 50Gi
```

Apply the persistent volume claims:

```bash
kubectl apply -f wso2-pv.yaml
```

Create ConfigMaps for WSO2 API Manager configuration:

```yaml
# wso2am-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: wso2am-config
  namespace: wso2
data:
  deployment.toml: |
    [server]
    hostname = "api.yourdomain.com"
    node_ip = "$env{NODE_IP}"
    base_path = "${carbon.protocol}://${carbon.host}:${carbon.management.port}"
    
    [user_store]
    type = "database_unique_id"
    
    [super_admin]
    username = "admin"
    password = "admin"
    create_admin_account = true
    
    [database.apim_db]
    type = "postgresql"
    url = "jdbc:postgresql://postgresql.databases.svc.cluster.local:5432/wso2am_db"
    username = "wso2am_user"
    password = "secure-wso2am-password"
    driver = "org.postgresql.Driver"
    
    [database.shared_db]
    type = "postgresql"
    url = "jdbc:postgresql://postgresql.databases.svc.cluster.local:5432/wso2shared_db"
    username = "wso2shared_user"
    password = "secure-wso2shared-password"
    driver = "org.postgresql.Driver"
    
    [keystore.tls]
    file_name = "wso2carbon.jks"
    type = "JKS"
    password = "wso2carbon"
    alias = "wso2carbon"
    key_password = "wso2carbon"
    
    [truststore]
    file_name = "client-truststore.jks"
    type = "JKS"
    password = "wso2carbon"
    
    [apim.gateway.environment.Default]
    name = "Default"
    type = "hybrid"
    provider = "wso2"
    display_in_api_console = true
    description = "This is a hybrid gateway that handles both production and sandbox token traffic."
    show_as_token_endpoint_url = true
    service_url = "https://api.yourdomain.com/services/"
    username = "${admin.username}"
    password = "${admin.password}"
    ws_endpoint = "ws://api.yourdomain.com:9099"
    wss_endpoint = "wss://api.yourdomain.com:8099"
    http_endpoint = "http://api.yourdomain.com"
    https_endpoint = "https://api.yourdomain.com"
    
    [apim.analytics]
    enable = true
    config_endpoint = "https://analytics.yourdomain.com:7444"
    auth_token = "your-analytics-auth-token"
    
    [transport.https.properties]
    proxyPort = 443
```

Apply the ConfigMap:

```bash
kubectl apply -f wso2am-configmap.yaml
```

Create the WSO2 API Manager deployment:

```yaml
# wso2am-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: wso2am
  namespace: wso2
spec:
  replicas: 2
  selector:
    matchLabels:
      app: wso2am
  template:
    metadata:
      labels:
        app: wso2am
    spec:
      containers:
      - name: wso2am
        image: wso2/wso2am:4.2.0
        ports:
        - containerPort: 9443
          name: https
        - containerPort: 8280
          name: http-gateway
        - containerPort: 8243
          name: https-gateway
        - containerPort: 9763
          name: http-servlet
        env:
        - name: NODE_IP
          valueFrom:
            fieldRef:
              fieldPath: status.podIP
        resources:
          requests:
            memory: "2Gi"
            cpu: "1000m"
          limits:
            memory: "4Gi"
            cpu: "2000m"
        volumeMounts:
        - name: wso2am-config-volume
          mountPath: /home/wso2carbon/wso2am-4.2.0/repository/conf/deployment.toml
          subPath: deployment.toml
        - name: wso2am-shared-storage
          mountPath: /home/wso2carbon/wso2am-4.2.0/repository/deployment/server
        livenessProbe:
          httpGet:
            path: /carbon/admin/login.jsp
            port: 9443
            scheme: HTTPS
          initialDelaySeconds: 300
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /carbon/admin/login.jsp
            port: 9443
            scheme: HTTPS
          initialDelaySeconds: 120
          periodSeconds: 10
      volumes:
      - name: wso2am-config-volume
        configMap:
          name: wso2am-config
      - name: wso2am-shared-storage
        persistentVolumeClaim:
          claimName: wso2am-shared-storage
---
apiVersion: v1
kind: Service
metadata:
  name: wso2am-service
  namespace: wso2
spec:
  selector:
    app: wso2am
  ports:
  - name: https
    port: 9443
    targetPort: 9443
  - name: http-gateway
    port: 8280
    targetPort: 8280
  - name: https-gateway
    port: 8243
    targetPort: 8243
  - name: http-servlet
    port: 9763
    targetPort: 9763
  type: ClusterIP
```

Deploy WSO2 API Manager:

```bash
kubectl apply -f wso2am-deployment.yaml
```

Create ingress for WSO2 API Manager:

```yaml
# wso2am-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: wso2am-ingress
  namespace: wso2
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/backend-protocol: "HTTPS"
    nginx.ingress.kubernetes.io/ssl-passthrough: "true"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - api.yourdomain.com
    secretName: wso2am-tls
  rules:
  - host: api.yourdomain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: wso2am-service
            port:
              number: 9443
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: wso2am-gateway-ingress
  namespace: wso2
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - gateway.yourdomain.com
    secretName: wso2am-gateway-tls
  rules:
  - host: gateway.yourdomain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: wso2am-service
            port:
              number: 8243
```

Apply the ingress configuration:

```bash
kubectl apply -f wso2am-ingress.yaml
```

Verify WSO2 API Manager deployment:

```bash
kubectl get pods -n wso2
kubectl get services -n wso2
kubectl get ingress -n wso2
kubectl logs -n wso2 -l app=wso2am
```

### Database Setup for WSO2 API Manager

WSO2 API Manager requires dedicated databases for API management data and shared configuration. Create the necessary databases and users in PostgreSQL.

Connect to PostgreSQL and create the required databases:

```sql
-- Connect to PostgreSQL as postgres user
CREATE USER wso2am_user WITH PASSWORD 'secure-wso2am-password';
CREATE DATABASE wso2am_db OWNER wso2am_user;
GRANT ALL PRIVILEGES ON DATABASE wso2am_db TO wso2am_user;

CREATE USER wso2shared_user WITH PASSWORD 'secure-wso2shared-password';
CREATE DATABASE wso2shared_db OWNER wso2shared_user;
GRANT ALL PRIVILEGES ON DATABASE wso2shared_db TO wso2shared_user;
```

Initialize the WSO2 API Manager database schema:

```bash
# Download WSO2 API Manager database scripts
kubectl exec -n wso2 wso2am-0 -- wget -O /tmp/postgresql.sql \
  https://raw.githubusercontent.com/wso2/carbon-apimgt/master/features/apimgt/org.wso2.carbon.apimgt.core.feature/src/main/resources/sql/postgresql.sql

# Execute the database schema creation
kubectl exec -n wso2 wso2am-0 -- psql -h postgresql.databases.svc.cluster.local \
  -U wso2am_user -d wso2am_db -f /tmp/postgresql.sql
```

## n8n Workflow Automation Platform

n8n provides visual workflow automation capabilities that enable rapid development and deployment of business process automation. The n8n deployment includes the main application, database integration, and webhook endpoints for external integrations.

### n8n Infrastructure Deployment

The n8n deployment utilizes Docker containers with persistent storage for workflow definitions and execution data. The deployment includes ingress configuration for web access and webhook endpoints.

Create a dedicated namespace for n8n:

```bash
kubectl create namespace n8n
kubectl label namespace n8n name=n8n
```

Create persistent storage for n8n data:

```yaml
# n8n-pv.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: n8n-data
  namespace: n8n
spec:
  accessModes:
    - ReadWriteOnce
  storageClassName: do-block-storage-ssd
  resources:
    requests:
      storage: 20Gi
```

Apply the persistent volume claim:

```bash
kubectl apply -f n8n-pv.yaml
```

Create n8n configuration:

```yaml
# n8n-config.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: n8n-config
  namespace: n8n
data:
  N8N_HOST: "n8n.yourdomain.com"
  N8N_PORT: "5678"
  N8N_PROTOCOL: "https"
  WEBHOOK_URL: "https://n8n.yourdomain.com/"
  GENERIC_TIMEZONE: "UTC"
  N8N_LOG_LEVEL: "info"
  N8N_METRICS: "true"
  N8N_DIAGNOSTICS_ENABLED: "false"
  N8N_VERSION_NOTIFICATIONS_ENABLED: "false"
  N8N_TEMPLATES_ENABLED: "true"
  N8N_ONBOARDING_FLOW_DISABLED: "true"
  N8N_PERSONALIZATION_ENABLED: "false"
---
apiVersion: v1
kind: Secret
metadata:
  name: n8n-secrets
  namespace: n8n
type: Opaque
stringData:
  DB_TYPE: "postgresdb"
  DB_POSTGRESDB_HOST: "postgresql.databases.svc.cluster.local"
  DB_POSTGRESDB_PORT: "5432"
  DB_POSTGRESDB_DATABASE: "n8n_db"
  DB_POSTGRESDB_USER: "n8n_user"
  DB_POSTGRESDB_PASSWORD: "secure-n8n-password"
  N8N_ENCRYPTION_KEY: "your-32-character-encryption-key"
```

Apply the configuration:

```bash
kubectl apply -f n8n-config.yaml
```

Create n8n deployment:

```yaml
# n8n-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: n8n
  namespace: n8n
spec:
  replicas: 2
  selector:
    matchLabels:
      app: n8n
  template:
    metadata:
      labels:
        app: n8n
    spec:
      containers:
      - name: n8n
        image: n8nio/n8n:1.15.1
        ports:
        - containerPort: 5678
          name: http
        env:
        - name: N8N_HOST
          valueFrom:
            configMapKeyRef:
              name: n8n-config
              key: N8N_HOST
        - name: N8N_PORT
          valueFrom:
            configMapKeyRef:
              name: n8n-config
              key: N8N_PORT
        - name: N8N_PROTOCOL
          valueFrom:
            configMapKeyRef:
              name: n8n-config
              key: N8N_PROTOCOL
        - name: WEBHOOK_URL
          valueFrom:
            configMapKeyRef:
              name: n8n-config
              key: WEBHOOK_URL
        - name: GENERIC_TIMEZONE
          valueFrom:
            configMapKeyRef:
              name: n8n-config
              key: GENERIC_TIMEZONE
        - name: DB_TYPE
          valueFrom:
            secretKeyRef:
              name: n8n-secrets
              key: DB_TYPE
        - name: DB_POSTGRESDB_HOST
          valueFrom:
            secretKeyRef:
              name: n8n-secrets
              key: DB_POSTGRESDB_HOST
        - name: DB_POSTGRESDB_PORT
          valueFrom:
            secretKeyRef:
              name: n8n-secrets
              key: DB_POSTGRESDB_PORT
        - name: DB_POSTGRESDB_DATABASE
          valueFrom:
            secretKeyRef:
              name: n8n-secrets
              key: DB_POSTGRESDB_DATABASE
        - name: DB_POSTGRESDB_USER
          valueFrom:
            secretKeyRef:
              name: n8n-secrets
              key: DB_POSTGRESDB_USER
        - name: DB_POSTGRESDB_PASSWORD
          valueFrom:
            secretKeyRef:
              name: n8n-secrets
              key: DB_POSTGRESDB_PASSWORD
        - name: N8N_ENCRYPTION_KEY
          valueFrom:
            secretKeyRef:
              name: n8n-secrets
              key: N8N_ENCRYPTION_KEY
        resources:
          requests:
            memory: "1Gi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "1000m"
        volumeMounts:
        - name: n8n-data
          mountPath: /home/node/.n8n
        livenessProbe:
          httpGet:
            path: /healthz
            port: 5678
          initialDelaySeconds: 60
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /healthz
            port: 5678
          initialDelaySeconds: 30
          periodSeconds: 10
      volumes:
      - name: n8n-data
        persistentVolumeClaim:
          claimName: n8n-data
---
apiVersion: v1
kind: Service
metadata:
  name: n8n-service
  namespace: n8n
spec:
  selector:
    app: n8n
  ports:
  - name: http
    port: 5678
    targetPort: 5678
  type: ClusterIP
```

Deploy n8n:

```bash
kubectl apply -f n8n-deployment.yaml
```

Create ingress for n8n:

```yaml
# n8n-ingress.yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: n8n-ingress
  namespace: n8n
  annotations:
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/proxy-body-size: "50m"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "300"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "300"
spec:
  ingressClassName: nginx
  tls:
  - hosts:
    - n8n.yourdomain.com
    secretName: n8n-tls
  rules:
  - host: n8n.yourdomain.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: n8n-service
            port:
              number: 5678
```

Apply the ingress configuration:

```bash
kubectl apply -f n8n-ingress.yaml
```

Verify n8n deployment:

```bash
kubectl get pods -n n8n
kubectl get services -n n8n
kubectl get ingress -n n8n
kubectl logs -n n8n -l app=n8n
```

### n8n Initial Configuration

Configure n8n for optimal performance and integration with the AI Agent Life Operating System. The configuration includes user setup, credential management, and initial workflow templates.

Access n8n through the web interface at https://n8n.yourdomain.com and complete the initial setup wizard. Create an admin user account and configure basic settings.

Create credentials for common integrations:

1. **PostgreSQL Connection:**
   - Type: Postgres
   - Host: postgresql.databases.svc.cluster.local
   - Database: aiagent
   - User: aiagent
   - Password: your-secure-user-password
   - Port: 5432

2. **HTTP Basic Auth:**
   - Type: HTTP Basic Auth
   - User: admin
   - Password: your-admin-password

3. **Generic OAuth2:**
   - Type: OAuth2 Generic
   - Authorization URL: Configure based on specific service
   - Access Token URL: Configure based on specific service
   - Client ID: Configure based on specific service
   - Client Secret: Configure based on specific service

This completes the core platform deployment for the AI Agent Life Operating System. The next phase involves developing comprehensive tool integration implementations and custom operators for the 209 AppSumo tools.

